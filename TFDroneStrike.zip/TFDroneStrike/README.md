# T-F DRONE STRIKE

FPV-дрон над Крымом/Донбассом: бомби окопы, технику, блиндажи и склады, тарань цели, сбивай Шахеды/Герани/FPV-дроны/ракеты. Проект сделан для Android, Unity 2022.3 LTS, IL2CPP + ARM64, **без анти-чита и обфускации** — чтобы на своей же игре тренировать реверс и читы.

Игра не собрана в этом окружении (здесь нет Unity). Ниже — как открыть и собрать APK на ПК.

## Требования

- Unity **2022.3 LTS** (проект помечен как `2022.3.22f1`; подойдёт любой 2022.3.x).
- Unity Hub → Installs → у установленной версии добавить модуль **Android Build Support** вместе с **SDK / NDK / JDK**.
- Windows/macOS/Linux с Unity Editor. Телефон нужен только для запуска готового APK.

## Открытие проекта

1. Скопируй папку `TFDroneStrike` на ПК.
2. Unity Hub → `Add` → выбери папку проекта.
3. Открой её. При первом импорте сработает автосетап: создаст `Assets/Scenes/Main.unity`, добавит её в Build Settings, выставит IL2CPP/ARM64/GLES3/Minimal stripping и создаст `Assets/Resources/TFStandard.mat`.
4. Если автосетап не сработал — меню сверху: **T-F → 1. Setup Project**.
5. Открыть сцену вручную: **T-F → 0. Open Main Scene**.
6. Нажми **Play** — проверить на клавиатуре.

## Сборка APK

- Меню **T-F → 2. Build APK (IL2CPP ARM64)**.
- Готовый файл: `Builds/TFDroneStrike.apk`.
- Для Google Play: **T-F → 3. Build AAB**.

Настройки сборки:

| Параметр | Значение |
|---|---|
| Scripting Backend | IL2CPP |
| Architecture | ARM64 only |
| Managed Stripping | Minimal |
| IL2CPP Config | Release |
| Graphics API | OpenGLES3 |
| Min Android | 7.0 (API 24) |
| Anti-cheat / obfuscation | нет |
| `link.xml` | `Assembly-CSharp` preserve all |

Установка: `adb install -r Builds/TFDroneStrike.apk` или скопировать APK на телефон и открыть.

## Управление

### ПК (клавиатура)

| Клавиши | Действие |
|---|---|
| W / S | тангаж |
| A / D | крен |
| Q / E | рыскание |
| Shift / Ctrl | тяга |
| Space | пулемёт |
| B | сброс бомбы |
| C | FPV / камера погони |
| Esc | пауза |
| F1 | помощь |

### Android (тач)

- Левый виртуальный стик — тяга / рыскание.
- Правый виртуальный стик — тангаж / крен.
- `ОГОНЬ` — пулемёт (держать).
- `БОМБА` — сброс бомбы.
- `II` — пауза; `ВИД` — камера.

## Геймплей

- Бомбы, пулемёт и таран. Взрыв бомбы и падение дрона бьют по площади.
- Цели: танки, БМП, грузовики, топливовозы, ЗУ-23, блиндажи/ДОТы, РЛС, склады ГСМ и боеприпасов, пехота, окопы.
- Противник: Шахеды/Герани, FPV-дроны, ракеты.
- Очки, волны, счётчик сбитых, рекорд в `PlayerPrefs` (`tf_best`).
- Батарея садится; на базе — перезарядка и перевооружение (подлетай медленно).
- Мини-карта, маркеры целей, килл-фид, радар-предупреждения.

## Структура

```
Assets/Scripts/Common.cs          IDamageable, InputState, примитивы, взрывы
Assets/Scripts/WorldAssets.cs     текстуры, материалы, fallback-ресурсы
Assets/Scripts/TerrainBuilder.cs  процедурная земля, море, траншеи, дороги
Assets/Scripts/MapBuilder.cs      база, деревня, техника, окопы, деревья, облака
Assets/Scripts/Target.cs          цели и их уничтожение
Assets/Scripts/EnemyAircraft.cs   Шахед/Герань, FPV, ракета
Assets/Scripts/DroneController.cs дрон, камера, пулемёт, бомбы, урон
Assets/Scripts/Bomb.cs            бомба
Assets/Scripts/GameManager.cs     очки, волны, спавн, пауза, рестарт
Assets/Scripts/HUD.cs             IMGUI-интерфейс, миникарта, маркеры
Assets/Scripts/TouchControls.cs   мобильные стики и кнопки
Assets/Scripts/FX.cs              взрывы, трассеры, дым, кольца
Assets/Scripts/AudioSynth.cs      процедурные звуки
Assets/Scripts/Bootstrap.cs       точка входа сцены
Assets/Editor/TFSetup.cs          автосетап сцены и PlayerSettings
Assets/Editor/TFBuild.cs          сборка APK/AAB
Assets/Resources/Shaders/         кастомные шейдеры (terrain/particles/sky)
Assets/Resources/Textures/        CC0-текстуры и сгенерированные water/camo
Assets/Resources/Fonts/           Roboto Regular/Bold (Apache 2.0) + лицензия
Assets/Resources/TFStandard.mat   создаётся автосетапом (гарантирует Standard в APK)
```

Сцена содержит только `Bootstrap`: мир, дрон, материалы и UI создаются в рантайме. Поэтому в проекте нет бинарных префабов и сложных сцен — удобно для реверса.

## Для практики читов (своя игра)

- В APK: `lib/arm64-v8a/libil2cpp.so` и `assets/bin/Data/Managed/Metadata/global-metadata.dat`.
- `link.xml` сохраняет все имена управляемого кода; stripping — Minimal, анти-чита и обфускации нет.
- Ориентиры в метаданных: `TF.GameManager` (`Score`, `Best`, `Started`, `Paused`), `TF.DroneController` (`Health`, `Battery`, `Ammo`, `Bombs`, `MaxThrust`, `PitchRate`), `TF.Target` (`Health`), `TF.EnemyAircraft` (`Health`, `Speed`), `TF.InputState`.
- IL2CPP Release не содержит C# IL, но `global-metadata.dat` + `libil2cpp.so` дают имена и структуры (Il2CppDumper). Дальше — Frida/native hook, патч памяти, правка `global-metadata.dat` или самой библиотеки. Используй только на своей сборке.

## Текстуры

- ambientCG (CC0): Grass004, Ground110, Ground054, Rock058, Concrete034, Metal032, Metal021, Planks037A. В проект положены уменьшенные 512×512 JPEG (`_Color`).
- `water.jpg` и `camo.jpg` сгенерированы процедурно (PIL) для этой игры.
- Шрифт Roboto Regular/Bold — Apache License 2.0, текст лицензии в `Assets/Resources/Fonts/LICENSE-Roboto.txt`.
- Если файл текстуры отсутствует, `WorldAssets` сгенерирует шумовой fallback — игра всё равно запустится.

## Ограничения

- APK здесь не собирался: в текущем окружении нет Unity Editor.
- Только ARM64 и Android 7+; x86/ARMv7 не включены.
- Интерфейс и тексты — на русском.
- Производительность зависит от телефона: сцена процедурная, много отдельных объектов; на слабых устройствах возможен низкий FPS.
- Игра использует Built-in Render Pipeline и старый Input Manager; Input System не требуется.
