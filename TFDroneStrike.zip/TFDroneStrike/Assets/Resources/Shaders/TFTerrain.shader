Shader "TF/Terrain"
{
    Properties
    {
        _GrassTex ("Grass", 2D) = "white" {}
        _DirtTex ("Dirt", 2D) = "white" {}
        _RockTex ("Rock", 2D) = "white" {}
        _SandTex ("Sand", 2D) = "white" {}
        _Brightness ("Brightness", Range(0.5, 1.5)) = 1.0
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" }
        LOD 200

        CGPROGRAM
        #pragma surface surf Standard fullforwardshadows
        #pragma target 3.0

        sampler2D _GrassTex;
        sampler2D _DirtTex;
        sampler2D _RockTex;
        sampler2D _SandTex;
        half _Brightness;

        struct Input
        {
            float3 worldPos;
            float4 color : COLOR;
        };

        void surf (Input IN, inout SurfaceOutputStandard o)
        {
            float3 wp = IN.worldPos;
            half4 w = IN.color;
            half sum = w.r + w.g + w.b + w.a;
            if (sum < 0.001h)
            {
                w = half4(1, 0, 0, 0);
                sum = 1;
            }
            w /= sum;

            half3 g = tex2D(_GrassTex, wp.xz * 0.085h).rgb;
            half3 d = tex2D(_DirtTex, wp.xz * 0.135h).rgb;
            half3 r = tex2D(_RockTex, wp.xz * 0.060h).rgb;
            half3 s = tex2D(_SandTex, wp.xz * 0.110h).rgb;

            half macro = 0.90h + 0.10h * sin(wp.x * 0.097h + sin(wp.z * 0.061h) * 1.7h);
            half3 albedo = g * w.r + d * w.g + r * w.b + s * w.a;
            o.Albedo = albedo * _Brightness * macro;
            o.Smoothness = 0.04h + w.b * 0.12h;
            o.Metallic = 0.0h;
            o.Occlusion = 1.0h;
        }
        ENDCG
    }
    FallBack "Diffuse"
}
