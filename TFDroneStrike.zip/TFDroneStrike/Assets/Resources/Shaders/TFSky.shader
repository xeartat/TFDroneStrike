Shader "TF/Sky"
{
    Properties
    {
        _TopColor ("Top", Color) = (0.16, 0.34, 0.62, 1)
        _HorizonColor ("Horizon", Color) = (0.72, 0.78, 0.84, 1)
        _GroundColor ("Ground", Color) = (0.30, 0.29, 0.25, 1)
        _SunColor ("Sun", Color) = (1.0, 0.85, 0.60, 1)
        _SunDir ("Sun Direction", Vector) = (0.35, 0.55, 0.15, 0)
        _SunSize ("Sun Size", Range(0.0001, 0.2)) = 0.025
    }
    SubShader
    {
        Tags { "Queue"="Background" "RenderType"="Background" "PreviewType"="Skybox" }
        Cull Off
        ZWrite Off

        Pass
        {
            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #include "UnityCG.cginc"

            fixed4 _TopColor;
            fixed4 _HorizonColor;
            fixed4 _GroundColor;
            fixed4 _SunColor;
            float4 _SunDir;
            float _SunSize;

            struct appdata
            {
                float4 vertex : POSITION;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float3 dir : TEXCOORD0;
            };

            v2f vert (appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.dir = mul((float3x3)unity_ObjectToWorld, v.vertex.xyz);
                return o;
            }

            fixed4 frag (v2f i) : SV_Target
            {
                float3 d = normalize(i.dir);
                float h = saturate(d.y * 1.2 + 0.10);
                float3 sky = lerp(_HorizonColor.rgb, _TopColor.rgb, pow(h, 0.62));
                float below = saturate(-d.y * 2.5);
                sky = lerp(sky, _GroundColor.rgb, below);

                float3 sd = normalize(_SunDir.xyz);
                float sun = saturate(dot(d, sd));
                float disk = smoothstep(1.0 - _SunSize, 1.0 - _SunSize * 0.45, sun);
                float glow = pow(sun, 18.0) * 0.30;
                sky += _SunColor.rgb * (disk * 1.4 + glow);

                return fixed4(sky, 1);
            }
            ENDCG
        }
    }
    FallBack Off
}
