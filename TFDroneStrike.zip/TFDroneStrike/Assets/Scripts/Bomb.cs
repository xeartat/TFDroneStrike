using UnityEngine;

namespace TF
{
    [RequireComponent(typeof(Rigidbody))]
    public class Bomb : MonoBehaviour
    {
        public Rigidbody Body;
        public SphereCollider Col;

        float armTime;
        bool exploded;

        public static Bomb Spawn(Vector3 pos, Vector3 velocity, DroneController owner)
        {
            var go = new GameObject("Бомба");
            go.layer = 2;
            go.transform.position = pos;
            var body = go.AddComponent<Rigidbody>();
            body.mass = 0.7f;
            body.drag = 0.02f;
            body.angularDrag = 0.15f;
            body.useGravity = true;
            body.interpolation = RigidbodyInterpolation.Interpolate;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            body.velocity = velocity;
            var col = go.AddComponent<SphereCollider>();
            col.radius = 0.21f;
            var b = go.AddComponent<Bomb>();
            b.Body = body;
            b.Col = col;
            b.armTime = Time.time + 0.08f;

            var visual = U.SphereL(go.transform, "Корпус", Vector3.zero, new Vector3(0.34f, 0.52f, 0.34f), WorldAssets.Camo, false);
            U.BoxL(go.transform, "Стабилизатор-1", new Vector3(0f, -0.2f, 0f), new Vector3(0.55f, 0.04f, 0.2f), WorldAssets.DarkMetal, null, false);
            U.BoxL(go.transform, "Стабилизатор-2", new Vector3(0f, -0.2f, 0f), new Vector3(0.2f, 0.04f, 0.55f), WorldAssets.DarkMetal, null, false);
            U.SphereL(go.transform, "Взрыватель", new Vector3(0f, 0.18f, 0f), Vector3.one * 0.12f, WorldAssets.LedRed, false);

            FX.Trail(go, new Color(0.6f, 0.6f, 0.55f, 0.45f), 0.18f, 1.1f);

            if (owner != null)
            {
                var ownCols = owner.GetComponentsInChildren<Collider>();
                for (int i = 0; i < ownCols.Length; i++) Physics.IgnoreCollision(col, ownCols[i]);
            }
            Object.Destroy(go, 25f);
            return b;
        }

        void Awake()
        {
            Body = GetComponent<Rigidbody>();
            Col = GetComponent<SphereCollider>();
        }

        void OnCollisionEnter(Collision collision)
        {
            if (exploded) return;
            if (Time.time < armTime) return;
            if (collision.collider != null && collision.collider.gameObject.layer == 2) return;
            Explode();
        }

        void Explode()
        {
            if (exploded) return;
            exploded = true;
            Vector3 p = transform.position;
            FX.Explosion(p, 1.25f);
            Combat.Blast(p, 13f, 250f, GameManager.I != null ? GameManager.I.Player : null);
            Object.Destroy(gameObject);
        }
    }
}
