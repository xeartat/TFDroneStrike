using UnityEngine;

namespace TF
{
    [DefaultExecutionOrder(-1000)]
    public class Bootstrap : MonoBehaviour
    {
        void Awake()
        {
            Application.targetFrameRate = 60;
            Application.runInBackground = true;
            QualitySettings.vSyncCount = 0;
            QualitySettings.antiAliasing = 2;
            QualitySettings.shadowDistance = 130f;
            QualitySettings.shadowCascades = 2;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Screen.orientation = ScreenOrientation.LandscapeLeft;
            Screen.autorotateToPortrait = false;
            Screen.autorotateToPortraitUpsideDown = false;
            Screen.autorotateToLandscapeLeft = true;
            Screen.autorotateToLandscapeRight = true;
            Input.multiTouchEnabled = true;
            Physics.queriesHitTriggers = true;

            WorldAssets.Init();
            AudioSynth.EnsureInit();
            FX.Init(transform);
            BuildLighting();

            var gm = gameObject.AddComponent<GameManager>();
            var world = new GameObject("Мир");

            var terrainGo = new GameObject("Генератор земли");
            var terrain = terrainGo.AddComponent<TerrainBuilder>();
            terrain.Build(world.transform);

            var map = gameObject.AddComponent<MapBuilder>();
            map.BuildAll(world.transform);

            Vector3 spawn = map.PlayerSpawn + Vector3.up * 0.1f;
            var player = DroneController.Create(spawn);
            gm.Begin(player, spawn);

            gameObject.AddComponent<HUD>();
            gameObject.AddComponent<TouchControls>();
        }

        void BuildLighting()
        {
            var sunGo = new GameObject("Солнце");
            var sun = sunGo.AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.color = new Color(1f, 0.92f, 0.78f);
            sun.intensity = 1.18f;
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.72f;
            sun.shadowBias = 0.04f;
            sun.shadowNormalBias = 0.35f;
            sunGo.transform.rotation = Quaternion.Euler(39f, -34f, 0f);
            RenderSettings.sun = sun;

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(0.52f, 0.62f, 0.76f);
            RenderSettings.ambientEquatorColor = new Color(0.36f, 0.38f, 0.34f);
            RenderSettings.ambientGroundColor = new Color(0.19f, 0.17f, 0.14f);

            if (WorldAssets.SkyMat != null)
            {
                WorldAssets.SkyMat.SetVector("_SunDir", -sunGo.transform.forward);
                RenderSettings.skybox = WorldAssets.SkyMat;
            }

            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogDensity = 0.0016f;
            RenderSettings.fogColor = new Color(0.66f, 0.73f, 0.81f);
        }
    }
}
