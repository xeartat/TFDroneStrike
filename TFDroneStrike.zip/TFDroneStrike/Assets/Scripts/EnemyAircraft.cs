using System.Collections.Generic;
using UnityEngine;

namespace TF
{
    public enum EnemyKind
    {
        Shahed,
        Fpv,
        Missile
    }

    public class EnemyAircraft : MonoBehaviour, IDamageable
    {
        public static readonly List<EnemyAircraft> All = new List<EnemyAircraft>();

        public EnemyKind Kind = EnemyKind.Shahed;
        public string Label = "ШАХЕД";
        public float Health = 55f;
        public float Speed = 25f;
        public float TurnRate = 65f;
        public float Damage = 60f;
        public float HitRadius = 10f;
        public int ScoreValue = 180;
        public bool Dead { get; private set; }
        public bool IsAlive { get { return !Dead; } }

        float life;
        AudioSource engine;

        public static EnemyAircraft Spawn(EnemyKind kind, Vector3 pos, Vector3 dir)
        {
            if (dir.sqrMagnitude < 0.01f) dir = Vector3.forward;
            dir.y = Mathf.Clamp(dir.y, -0.35f, 0.35f);
            dir.Normalize();

            var go = new GameObject(kind == EnemyKind.Shahed ? "Шахед" : (kind == EnemyKind.Fpv ? "FPV-дрон" : "Ракета"));
            go.transform.position = pos;
            go.transform.rotation = Quaternion.LookRotation(dir.normalized, Vector3.up);
            var rb = go.AddComponent<Rigidbody>();
            rb.isKinematic = true;
            rb.useGravity = false;
            var col = go.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.radius = kind == EnemyKind.Shahed ? 2.2f : (kind == EnemyKind.Fpv ? 0.9f : 1.4f);

            var e = go.AddComponent<EnemyAircraft>();
            e.Kind = kind;
            e.Configure();
            if (kind == EnemyKind.Shahed && Random.value < 0.5f) e.Label = "ГЕРАНЬ";
            e.BuildVisual();
            AudioSynth.EnsureInit();
            if (kind == EnemyKind.Missile)
                AudioSynth.Play(AudioSynth.Missile, pos, 0.75f, 1f, 800f);
            return e;
        }

        void Awake()
        {
            All.Add(this);
        }

        void OnDestroy()
        {
            All.Remove(this);
        }

        void Configure()
        {
            switch (Kind)
            {
                case EnemyKind.Shahed:
                    Label = "ШАХЕД";
                    Health = 55f;
                    Speed = 25f;
                    TurnRate = 65f;
                    Damage = 60f;
                    HitRadius = 11f;
                    ScoreValue = 180;
                    break;
                case EnemyKind.Fpv:
                    Label = "FPV-ДРОН";
                    Health = 30f;
                    Speed = 22f;
                    TurnRate = 120f;
                    Damage = 45f;
                    HitRadius = 4.5f;
                    ScoreValue = 120;
                    break;
                default:
                    Label = "РАКЕТА";
                    Health = 45f;
                    Speed = 45f;
                    TurnRate = 0f;
                    Damage = 75f;
                    HitRadius = 9f;
                    ScoreValue = 300;
                    break;
            }
        }

        void Start()
        {
            AudioSynth.EnsureInit();
            engine = gameObject.AddComponent<AudioSource>();
            engine.clip = AudioSynth.Engine;
            engine.loop = true;
            engine.volume = Kind == EnemyKind.Missile ? 0.28f : 0.20f;
            engine.pitch = Kind == EnemyKind.Shahed ? 0.72f : (Kind == EnemyKind.Fpv ? 1.45f : 1.8f);
            engine.spatialBlend = 1f;
            engine.rolloffMode = AudioRolloffMode.Linear;
            engine.minDistance = 6f;
            engine.maxDistance = 700f;
            engine.dopplerLevel = 0.5f;
            if (engine.clip != null) engine.Play();
        }

        void Update()
        {
            if (Dead) return;
            if (GameManager.I != null && GameManager.I.Paused) return;
            life += Time.deltaTime;

            Vector3 target;
            if (GameManager.I != null && GameManager.I.Player != null && !GameManager.I.Player.Dead)
                target = GameManager.I.Player.transform.position;
            else if (GameManager.I != null)
                target = GameManager.I.SpawnPoint + Vector3.up * 2f;
            else
                target = transform.position + transform.forward * 100f;

            if (Kind == EnemyKind.Missile)
            {
                transform.position += transform.forward * Speed * Time.deltaTime;
            }
            else
            {
                Vector3 to = target - transform.position;
                if (to.sqrMagnitude > 0.01f)
                {
                    Vector3 dir = to.normalized;
                    transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.LookRotation(dir, Vector3.up), TurnRate * Time.deltaTime);
                }
                transform.position += transform.forward * Speed * Time.deltaTime;
            }

            if (GameManager.I != null && GameManager.I.Player != null && !GameManager.I.Player.Dead)
            {
                float d = Vector3.Distance(transform.position, GameManager.I.Player.transform.position);
                if (d < HitRadius) Detonate(true);
            }

            if (!Dead && Kind == EnemyKind.Shahed && GameManager.I != null)
            {
                if (Vector3.Distance(transform.position, GameManager.I.SpawnPoint) < 24f)
                {
                    GameManager.I.OnBaseHit();
                    Detonate(false);
                }
            }

            if (!Dead && (life > 110f || transform.position.y < -3f || Mathf.Abs(transform.position.x) > 650f || Mathf.Abs(transform.position.z) > 650f))
                Destroy(gameObject);
        }

        public void TakeDamage(float amount, Vector3 point)
        {
            if (Dead) return;
            Health -= amount;
            FX.Impact(point, Vector3.up, true);
            AudioSynth.Play(AudioSynth.Click, point, 0.25f, 1.3f, 120f);
            if (Health <= 0f) Die(true);
        }

        void Die(bool byPlayer)
        {
            if (Dead) return;
            Dead = true;
            FX.Explosion(transform.position, Kind == EnemyKind.Missile ? 1.7f : 1.0f);
            if (byPlayer && GameManager.I != null) GameManager.I.OnEnemyKilled(this);
            Destroy(gameObject);
        }

        void Detonate(bool hurtPlayer)
        {
            if (Dead) return;
            Dead = true;
            FX.Explosion(transform.position, Kind == EnemyKind.Missile ? 1.7f : 1.1f);
            if (hurtPlayer && GameManager.I != null && GameManager.I.Player != null)
                GameManager.I.Player.TakeDamage(Damage, transform.position);
            Destroy(gameObject);
        }

        void BuildVisual()
        {
            var t = transform;
            if (Kind == EnemyKind.Shahed)
            {
                U.CylL(t, "Корпус", Vector3.zero, 0.38f, 2.9f, WorldAssets.DarkMetal, Quaternion.Euler(90f, 0f, 0f), false);
                U.SphereL(t, "Нос", new Vector3(0f, 0f, 1.5f), new Vector3(0.42f, 0.42f, 0.8f), WorldAssets.Metal, false);
                U.BoxL(t, "Крыло", new Vector3(0f, 0.03f, -0.1f), new Vector3(4.8f, 0.09f, 1.25f), WorldAssets.DarkMetal, null, false);
                U.BoxL(t, "Крыло-Л", new Vector3(-1.7f, 0.03f, 0.32f), new Vector3(1.8f, 0.08f, 0.85f), WorldAssets.DarkMetal, Quaternion.Euler(0f, 16f, 0f), false);
                U.BoxL(t, "Крыло-П", new Vector3(1.7f, 0.03f, 0.32f), new Vector3(1.8f, 0.08f, 0.85f), WorldAssets.DarkMetal, Quaternion.Euler(0f, -16f, 0f), false);
                U.BoxL(t, "Стабилизатор", new Vector3(0f, 0.02f, -1.35f), new Vector3(2.0f, 0.06f, 0.55f), WorldAssets.DarkMetal, null, false);
                U.BoxL(t, "Киль", new Vector3(0f, 0.5f, -1.35f), new Vector3(0.07f, 1.0f, 0.9f), WorldAssets.DarkMetal, null, false);
                U.SphereL(t, "Бак", new Vector3(0f, 0f, 0.3f), new Vector3(0.55f, 0.32f, 1.5f), WorldAssets.Rust, false);
                var prop = new GameObject("Винт").transform;
                prop.SetParent(t, false);
                prop.localPosition = new Vector3(0f, 0f, -1.62f);
                U.BoxL(prop, "Лопасть-1", Vector3.zero, new Vector3(0.06f, 0.9f, 0.03f), WorldAssets.Dark, null, false);
                U.BoxL(prop, "Лопасть-2", Vector3.zero, new Vector3(0.9f, 0.06f, 0.03f), WorldAssets.Dark, null, false);
                prop.gameObject.AddComponent<Spin>().Setup(Vector3.forward, 900f);
                FX.Trail(gameObject, new Color(0.38f, 0.37f, 0.35f, 0.55f), 1.3f, 5.5f);
            }
            else if (Kind == EnemyKind.Fpv)
            {
                U.BoxL(t, "Рама", Vector3.zero, new Vector3(0.38f, 0.10f, 0.46f), WorldAssets.Dark, null, false);
                for (int i = 0; i < 4; i++)
                {
                    float a = 45f + i * 90f;
                    var arm = U.BoxL(t, "Луч", Quaternion.Euler(0f, a, 0f) * new Vector3(0f, 0f, 0.30f), new Vector3(0.055f, 0.035f, 0.62f), WorldAssets.Dark, Quaternion.Euler(0f, a, 0f), false);
                    Vector3 mp = Quaternion.Euler(0f, a, 0f) * new Vector3(0f, 0.02f, 0.52f);
                    U.CylL(t, "Мотор", mp, 0.13f, 0.09f, WorldAssets.DarkMetal, null, false);
                    U.CylL(t, "Пропеллер", mp + Vector3.up * 0.08f, 0.34f, 0.012f, WorldAssets.Dark, null, false);
                }
                U.BoxL(t, "Камера", new Vector3(0f, 0.08f, 0.26f), new Vector3(0.14f, 0.12f, 0.16f), WorldAssets.Glass, null, false);
                U.SphereL(t, "Светодиод", new Vector3(0.15f, 0.05f, -0.18f), Vector3.one * 0.05f, WorldAssets.LedRed, false);
                FX.Trail(gameObject, new Color(0.25f, 0.25f, 0.25f, 0.4f), 0.22f, 1.6f);
            }
            else
            {
                U.CylL(t, "Корпус", Vector3.zero, 0.62f, 5.4f, WorldAssets.White, Quaternion.Euler(90f, 0f, 0f), false);
                U.SphereL(t, "Нос", new Vector3(0f, 0f, 2.85f), new Vector3(0.62f, 0.62f, 1.1f), WorldAssets.Metal, false);
                U.BoxL(t, "Крыло", new Vector3(0f, 0f, -1.8f), new Vector3(3.0f, 0.08f, 0.8f), WorldAssets.Metal, null, false);
                U.BoxL(t, "Киль", new Vector3(0f, 0.45f, -2.2f), new Vector3(0.08f, 0.9f, 0.7f), WorldAssets.Metal, null, false);
                U.SphereL(t, "Двигатель", new Vector3(0f, 0f, -2.85f), Vector3.one * 0.45f, WorldAssets.LedRed, false);
                FX.Trail(gameObject, new Color(0.72f, 0.70f, 0.66f, 0.7f), 1.6f, 6.5f);
            }
        }
    }
}
