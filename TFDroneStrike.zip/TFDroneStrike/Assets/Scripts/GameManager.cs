using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace TF
{
    public class GameManager : MonoBehaviour
    {
        public struct FeedMsg
        {
            public string Text;
            public Color Color;
            public float Time;
        }

        public static GameManager I;

        public DroneController Player;
        public Vector3 SpawnPoint;
        public bool Started;
        public bool Paused;
        public int Score;
        public int Kills;
        public int Deaths;
        public int Wave = 1;
        public int Best;
        public float RunTime;

        public readonly List<FeedMsg> Events = new List<FeedMsg>();

        float enemyTimer;
        float targetTimer;
        float saveAt;

        void Awake()
        {
            I = this;
            Best = PlayerPrefs.GetInt("tf_best", 0);
            Target.All.Clear();
            EnemyAircraft.All.Clear();
            Time.timeScale = 1f;
        }

        void OnDestroy()
        {
            if (I == this) I = null;
            Time.timeScale = 1f;
            AudioListener.pause = false;
        }

        public void Begin(DroneController player, Vector3 spawn)
        {
            I = this;
            Player = player;
            SpawnPoint = spawn;
            Started = false;
            Paused = false;
            Feed("ДРОН НА ПОЗИЦИИ. ЖМИ «ВЗЛЁТ»", new Color(0.8f, 0.9f, 1f));
        }

        public void StartRun()
        {
            if (Started) return;
            Started = true;
            Paused = false;
            Score = 0;
            Kills = 0;
            Deaths = 0;
            Wave = 1;
            RunTime = 0f;
            enemyTimer = 9f;
            targetTimer = 18f;
            Events.Clear();
            Time.timeScale = 1f;
            AudioListener.pause = false;
            InputState.ResetAll();
            Feed("ВЗЛЁТ РАЗРЕШЁН. РАБОТАЙ.", new Color(0.55f, 1f, 0.55f));
            AudioSynth.Play2D(AudioSynth.Alarm, 0.25f, 0.7f);
        }

        void Update()
        {
            if (!Started) return;
            if (Paused)
            {
                CleanupEvents();
                return;
            }

            RunTime += Time.deltaTime;
            enemyTimer -= Time.deltaTime;
            targetTimer -= Time.deltaTime;

            if (Time.unscaledTime > saveAt)
            {
                saveAt = Time.unscaledTime + 5f;
                if (Score > Best)
                {
                    Best = Score;
                    PlayerPrefs.SetInt("tf_best", Best);
                }
            }

            if (enemyTimer <= 0f)
            {
                if (EnemyAircraft.All.Count >= 7)
                {
                    enemyTimer = 1.5f;
                }
                else
                {
                    SpawnEnemy();
                    enemyTimer = Mathf.Lerp(12.5f, 5.5f, Mathf.Clamp01(Score / 4000f)) + Random.Range(-1.6f, 1.6f);
                }
            }

            if (RunTime > Wave * 75f)
            {
                Wave++;
                Feed("ВОЛНА " + Wave + " — ПРОТИВНИК АКТИВНЕЕ", new Color(1f, 0.65f, 0.25f));
            }

            if (targetTimer <= 0f)
            {
                targetTimer = 6f;
                int heavy = AliveHeavyCount();
                if (heavy < 6 && MapBuilder.I != null)
                {
                    MapBuilder.I.SpawnReinforcement();
                    Feed("ПОДКРЕПЛЕНИЕ ПРОТИВНИКА ВЫДВИГАЕТСЯ", new Color(1f, 0.6f, 0.2f));
                }
            }

            CleanupEvents();
        }

        int AliveHeavyCount()
        {
            int c = 0;
            for (int i = 0; i < Target.All.Count; i++)
            {
                var t = Target.All[i];
                if (t == null || t.Destroyed) continue;
                if (t.Kind != TargetKind.Infantry) c++;
            }
            return c;
        }

        void SpawnEnemy()
        {
            if (Player == null) return;
            Vector3 pp = Player.transform.position;

            int roll = Random.Range(0, 100);
            EnemyKind kind;
            if (roll < 58) kind = EnemyKind.Shahed;
            else if (roll < 85) kind = EnemyKind.Fpv;
            else kind = EnemyKind.Missile;

            Vector3 pos;
            if (kind == EnemyKind.Missile)
            {
                pos = new Vector3(-360f, Random.Range(32f, 78f), Mathf.Clamp(pp.z + Random.Range(-150f, 150f), -330f, 330f));
            }
            else
            {
                float ang = Random.Range(0f, Mathf.PI * 2f);
                float radius = kind == EnemyKind.Shahed ? Random.Range(280f, 380f) : Random.Range(120f, 220f);
                float alt = kind == EnemyKind.Shahed ? Random.Range(55f, 115f) : Random.Range(22f, 65f);
                pos = new Vector3(
                    Mathf.Clamp(pp.x + Mathf.Cos(ang) * radius, -355f, 355f),
                    alt,
                    Mathf.Clamp(pp.z + Mathf.Sin(ang) * radius, -355f, 355f));
            }

            Vector3 dir = (pp + Vector3.up * 10f - pos).normalized;
            var e = EnemyAircraft.Spawn(kind, pos, dir);
            if (e != null)
            {
                Feed("ПЕРЕХВАТ: " + e.Label, new Color(1f, 0.32f, 0.25f));
                AudioSynth.Play2D(AudioSynth.Alarm, 0.35f, 1f);
            }
        }

        public void OnTargetDestroyed(Target t)
        {
            if (t == null) return;
            Kills++;
            AddScore(t.Score, t.Label + " УНИЧТОЖЕН", new Color(1f, 0.85f, 0.32f));
        }

        public void OnEnemyKilled(EnemyAircraft e)
        {
            if (e == null) return;
            Kills++;
            AddScore(e.ScoreValue, "СБИТ: " + e.Label, new Color(0.55f, 1f, 0.55f));
        }

        public void OnPlayerDown(string reason)
        {
            Deaths++;
            Feed("ДРОН ПОТЕРЯН: " + reason, new Color(1f, 0.28f, 0.22f));
            AudioSynth.Play2D(AudioSynth.Alarm, 0.55f, 0.75f);
            if (Score > Best)
            {
                Best = Score;
                PlayerPrefs.SetInt("tf_best", Best);
            }
        }

        public void OnBaseHit()
        {
            Feed("БАЗА ПОД УДАРОМ", new Color(1f, 0.25f, 0.2f));
            Score = Mathf.Max(0, Score - 100);
            AudioSynth.Play2D(AudioSynth.Boom, 0.5f, 0.9f);
        }

        public void AddScore(int amount, string text, Color c)
        {
            Score += amount;
            Feed(text + "  +" + amount, c);
            if (Score > Best)
            {
                Best = Score;
                PlayerPrefs.SetInt("tf_best", Best);
            }
        }

        public void Feed(string text, Color color)
        {
            Events.Add(new FeedMsg { Text = text, Color = color, Time = Time.unscaledTime });
            if (Events.Count > 10) Events.RemoveAt(0);
        }

        void CleanupEvents()
        {
            float now = Time.unscaledTime;
            while (Events.Count > 0 && now - Events[0].Time > 8f) Events.RemoveAt(0);
        }

        public void TogglePause()
        {
            if (!Started) return;
            Paused = !Paused;
            Time.timeScale = Paused ? 0f : 1f;
            AudioListener.pause = Paused;
            InputState.ResetAll();
        }

        public void Restart()
        {
            Time.timeScale = 1f;
            AudioListener.pause = false;
            var scene = SceneManager.GetActiveScene();
            if (!string.IsNullOrEmpty(scene.name)) SceneManager.LoadScene(scene.name);
        }

        public void Quit()
        {
            Time.timeScale = 1f;
            AudioListener.pause = false;
            Application.Quit();
        }
    }
}
