using System.Collections.Generic;
using UnityEngine;

namespace TF
{
    public class TerrainBuilder : MonoBehaviour
    {
        public static TerrainBuilder I;

        public const float MapSize = 760f;
        public const float HalfSize = MapSize * 0.5f;
        public int Res = 192;
        public float SeaLevel = -0.6f;

        public readonly List<Vector2[]> TrenchSegments = new List<Vector2[]>();
        public readonly List<Vector2[]> Roads = new List<Vector2[]>();
        public readonly List<Rect> Fields = new List<Rect>();
        public readonly List<Vector3> Craters = new List<Vector3>();

        public Vector2 BaseCenter = new Vector2(0f, -30f);
        public Vector2 VillageCenter = new Vector2(-90f, 105f);
        public float BaseGround = 5.0f;
        public float VillageGround = 7.5f;

        Mesh terrainMesh;

        void Awake()
        {
            I = this;
            Layout();
        }

        void OnDestroy()
        {
            if (I == this) I = null;
        }

        void Layout()
        {
            TrenchSegments.Clear();
            TrenchSegments.Add(new[] { new Vector2(58f, 18f), new Vector2(94f, 34f), new Vector2(108f, 64f), new Vector2(143f, 82f), new Vector2(150f, 116f), new Vector2(121f, 132f) });
            TrenchSegments.Add(new[] { new Vector2(94f, 34f), new Vector2(70f, 56f), new Vector2(78f, 86f) });
            TrenchSegments.Add(new[] { new Vector2(143f, 82f), new Vector2(176f, 70f), new Vector2(202f, 84f) });

            Roads.Clear();
            Roads.Add(new[] { new Vector2(0f, -30f), new Vector2(-30f, 40f), new Vector2(-90f, 105f), new Vector2(-180f, 150f), new Vector2(-280f, 172f) });
            Roads.Add(new[] { new Vector2(0f, -30f), new Vector2(90f, -72f), new Vector2(190f, -112f), new Vector2(300f, -140f) });
            Roads.Add(new[] { new Vector2(0f, -30f), new Vector2(58f, 18f), new Vector2(120f, 60f), new Vector2(160f, 110f) });

            Fields.Clear();
            Fields.Add(new Rect(-225f, -185f, 140f, 110f));
            Fields.Add(new Rect(35f, -255f, 150f, 105f));
            Fields.Add(new Rect(-285f, 150f, 125f, 105f));
            Fields.Add(new Rect(180f, -35f, 130f, 110f));
            Fields.Add(new Rect(-170f, 245f, 150f, 90f));

            Craters.Clear();
            var rng = new System.Random(20241109);
            int guard = 0;
            while (Craters.Count < 16 && guard++ < 500)
            {
                float x = Mathf.Lerp(-270f, 330f, (float)rng.NextDouble());
                float z = Mathf.Lerp(-330f, 330f, (float)rng.NextDouble());
                if (Vector2.Distance(new Vector2(x, z), BaseCenter) < 55f) continue;
                if (Vector2.Distance(new Vector2(x, z), VillageCenter) < 45f) continue;
                float r = Mathf.Lerp(2.2f, 6.5f, (float)rng.NextDouble());
                Craters.Add(new Vector3(x, z, r));
            }
        }

        public float Height(float x, float z)
        {
            float coast = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(-380f, -300f, x));
            float baseH = Mathf.Lerp(-6.0f, 3.4f, coast);
            float n1 = Fbm(x * 0.0065f, z * 0.0065f, 4);
            float n2 = Fbm(x * 0.022f + 37f, z * 0.022f + 11f, 3);
            float h = baseH + (n1 - 0.48f) * 34f * coast + (n2 - 0.5f) * 6.5f * coast;
            h += Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(140f, 380f, x)) * (Fbm(x * 0.009f + 5f, z * 0.009f, 2) - 0.4f) * 15f * coast;

            h = Flatten(h, x, z, BaseCenter.x, BaseCenter.y, 68f, BaseGround, 30f);
            h = Flatten(h, x, z, VillageCenter.x, VillageCenter.y, 58f, VillageGround, 26f);

            h -= TrenchMask(x, z) * 2.4f;
            h -= CraterMask(x, z) * 1.4f;
            return Mathf.Max(h, -8f);
        }

        public Vector3 Point(float x, float z)
        {
            return new Vector3(x, Height(x, z), z);
        }

        public static float GetHeight(float x, float z)
        {
            return I != null ? I.Height(x, z) : 0f;
        }

        public static float Ground(Vector3 p)
        {
            return GetHeight(p.x, p.z);
        }

        static float Fbm(float x, float z, int octaves)
        {
            float v = 0f;
            float amp = 0.52f;
            float f = 1f;
            for (int i = 0; i < octaves; i++)
            {
                v += amp * Mathf.PerlinNoise(x * f + 31.7f, z * f + 17.3f);
                f *= 2.03f;
                amp *= 0.5f;
            }
            return v;
        }

        static float Flatten(float h, float x, float z, float cx, float cz, float radius, float target, float feather)
        {
            float d = Vector2.Distance(new Vector2(x, z), new Vector2(cx, cz));
            float t = 1f - Mathf.SmoothStep(radius, radius + feather, d);
            return Mathf.Lerp(h, target, t * 0.94f);
        }

        public float TrenchMask(float x, float z)
        {
            float best = 9999f;
            var p = new Vector2(x, z);
            for (int s = 0; s < TrenchSegments.Count; s++)
            {
                var seg = TrenchSegments[s];
                for (int i = 0; i < seg.Length - 1; i++)
                {
                    float d = DistToSegment(p, seg[i], seg[i + 1]);
                    if (d < best) best = d;
                }
            }
            return 1f - Mathf.SmoothStep(3.1f, 5.8f, best);
        }

        public float RoadMask(float x, float z)
        {
            float best = 9999f;
            var p = new Vector2(x, z);
            for (int s = 0; s < Roads.Count; s++)
            {
                var seg = Roads[s];
                for (int i = 0; i < seg.Length - 1; i++)
                {
                    float d = DistToSegment(p, seg[i], seg[i + 1]);
                    if (d < best) best = d;
                }
            }
            return 1f - Mathf.SmoothStep(3.6f, 8.0f, best);
        }

        public float CraterMask(float x, float z)
        {
            float m = 0f;
            for (int i = 0; i < Craters.Count; i++)
            {
                var c = Craters[i];
                float d = Vector2.Distance(new Vector2(x, z), new Vector2(c.x, c.y));
                if (d < c.z)
                {
                    float k = 1f - d / c.z;
                    m = Mathf.Max(m, k * k);
                }
            }
            return m;
        }

        float FieldMask(float x, float z)
        {
            for (int i = 0; i < Fields.Count; i++)
            {
                var f = Fields[i];
                if (x < f.xMin || x > f.xMax || z < f.yMin || z > f.yMax) continue;
                float edge = Mathf.Min(Mathf.Min(x - f.xMin, f.xMax - x), Mathf.Min(z - f.yMin, f.yMax - z));
                float edgeFade = Mathf.Clamp01(edge / 12f);
                float stripe = 0.40f + 0.38f * Mathf.Abs(Mathf.Sin(x * 0.52f + z * 0.17f));
                return stripe * (0.55f + 0.45f * edgeFade);
            }
            return 0f;
        }

        static float DistToSegment(Vector2 p, Vector2 a, Vector2 b)
        {
            Vector2 ab = b - a;
            float len2 = ab.sqrMagnitude;
            if (len2 < 0.0001f) return Vector2.Distance(p, a);
            float t = Mathf.Clamp01(Vector2.Dot(p - a, ab) / len2);
            return Vector2.Distance(p, a + ab * t);
        }

        public void Build(Transform parent)
        {
            var go = new GameObject("Terrain");
            go.transform.SetParent(parent, false);
            go.transform.position = Vector3.zero;
            var mf = go.AddComponent<MeshFilter>();
            var mr = go.AddComponent<MeshRenderer>();
            mr.sharedMaterial = WorldAssets.TerrainMat;
            mr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.On;
            mr.receiveShadows = true;

            int n = Res + 1;
            float step = MapSize / Res;
            var heights = new float[n * n];
            var verts = new Vector3[n * n];
            var uvs = new Vector2[n * n];
            var cols = new Color[n * n];

            for (int iz = 0; iz < n; iz++)
            {
                float z = -HalfSize + iz * step;
                for (int ix = 0; ix < n; ix++)
                {
                    float x = -HalfSize + ix * step;
                    float h = Height(x, z);
                    heights[iz * n + ix] = h;
                    verts[iz * n + ix] = new Vector3(x, h, z);
                    uvs[iz * n + ix] = new Vector2(x, z) * 0.1f;
                }
            }

            for (int iz = 0; iz < n; iz++)
            {
                float z = -HalfSize + iz * step;
                for (int ix = 0; ix < n; ix++)
                {
                    float x = -HalfSize + ix * step;
                    float h = heights[iz * n + ix];
                    float hl = heights[iz * n + Mathf.Max(0, ix - 1)];
                    float hr = heights[iz * n + Mathf.Min(n - 1, ix + 1)];
                    float hd = heights[Mathf.Max(0, iz - 1) * n + ix];
                    float hu = heights[Mathf.Min(n - 1, iz + 1) * n + ix];
                    float slope = Mathf.Max(Mathf.Abs(hr - hl), Mathf.Abs(hu - hd)) / (step * 2f);
                    cols[iz * n + ix] = TerrainColor(x, z, h, slope);
                }
            }

            var tris = new int[Res * Res * 6];
            int t = 0;
            for (int iz = 0; iz < Res; iz++)
            {
                for (int ix = 0; ix < Res; ix++)
                {
                    int i0 = iz * n + ix;
                    int i1 = i0 + 1;
                    int i2 = i0 + n;
                    int i3 = i2 + 1;
                    tris[t++] = i0;
                    tris[t++] = i2;
                    tris[t++] = i1;
                    tris[t++] = i1;
                    tris[t++] = i2;
                    tris[t++] = i3;
                }
            }

            var mesh = new Mesh();
            mesh.name = "TF_Terrain";
            mesh.vertices = verts;
            mesh.uv = uvs;
            mesh.colors = cols;
            mesh.triangles = tris;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            mesh.UploadMeshData(false);
            terrainMesh = mesh;
            mf.sharedMesh = mesh;

            var mc = go.AddComponent<MeshCollider>();
            mc.sharedMesh = mesh;

            var sea = GameObject.CreatePrimitive(PrimitiveType.Plane);
            sea.name = "Sea";
            sea.transform.SetParent(parent, false);
            sea.transform.position = new Vector3(0f, SeaLevel, 0f);
            sea.transform.localScale = new Vector3(320f, 1f, 320f);
            var sr = sea.GetComponent<Renderer>();
            sr.sharedMaterial = WorldAssets.Water;
            sr.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            sea.AddComponent<WaterAnimator>();
        }

        Color TerrainColor(float x, float z, float h, float slope)
        {
            float road = RoadMask(x, z);
            float trench = TrenchMask(x, z);
            float crater = CraterMask(x, z);
            float field = FieldMask(x, z);

            float sand = Mathf.Clamp01((3.2f - h) / 5.0f);
            sand = Mathf.Max(sand, Mathf.Clamp01(Mathf.InverseLerp(-290f, -340f, x)));
            float rock = Mathf.Clamp01((slope - 0.34f) * 2.6f);
            float dirt = Mathf.Max(road, trench);
            dirt = Mathf.Max(dirt, crater * 0.9f);
            dirt = Mathf.Max(dirt, field * 0.72f);

            float grass = Mathf.Clamp01(1f - Mathf.Max(dirt, Mathf.Max(rock, sand)));
            return new Color(grass, dirt, rock, sand);
        }

        public Vector3 RandomLandPoint(System.Random rng, float minX = -280f, float maxX = 330f, float minZ = -330f, float maxZ = 330f)
        {
            float x = Mathf.Lerp(minX, maxX, (float)rng.NextDouble());
            float z = Mathf.Lerp(minZ, maxZ, (float)rng.NextDouble());
            return new Vector3(x, Height(x, z), z);
        }
    }

    public class WaterAnimator : MonoBehaviour
    {
        Material mat;
        void Start()
        {
            var r = GetComponent<Renderer>();
            if (r != null) mat = r.material;
        }
        void Update()
        {
            if (mat == null) return;
            mat.mainTextureOffset = new Vector2(Time.time * 0.006f, Time.time * 0.0035f);
        }
    }
}
