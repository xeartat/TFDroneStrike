using UnityEngine;

namespace TF
{
    [DefaultExecutionOrder(-500)]
    public class TouchControls : MonoBehaviour
    {
        int leftId = -1;
        int rightId = -1;
        int fireId = -1;
        Vector2 leftOrigin;
        Vector2 rightOrigin;
        Vector2 leftVec;
        Vector2 rightVec;
        GUIStyle label;
        GUIStyle small;
        int styleH;
        Font font;
        Font fontBold;

        float Sc { get { return Mathf.Clamp(Screen.height / 900f, 0.8f, 1.6f); } }

        Rect PauseRect { get { float s = Sc; return new Rect(16 * s, 16 * s, 46 * s, 46 * s); } }
        Rect CamRect { get { float s = Sc; return new Rect(16 * s, 172 * s, 46 * s, 46 * s); } }
        Rect FireRect
        {
            get
            {
                float s = Sc;
                return new Rect(Screen.width - 154 * s, Screen.height - 164 * s, 126 * s, 126 * s);
            }
        }
        Rect BombRect
        {
            get
            {
                float s = Sc;
                return new Rect(Screen.width - 284 * s, Screen.height - 128 * s, 94 * s, 94 * s);
            }
        }

        bool Active
        {
            get
            {
                var gm = GameManager.I;
                return Application.isMobilePlatform && gm != null && gm.Started && !gm.Paused && gm.Player != null && !gm.Player.Dead;
            }
        }

        void Update()
        {
            if (!Application.isMobilePlatform) return;
            if (!Active)
            {
                leftId = rightId = fireId = -1;
                leftVec = rightVec = Vector2.zero;
                InputState.ResetAll();
                return;
            }

            InputState.Move = Vector2.zero;
            InputState.Aim = Vector2.zero;
            InputState.Fire = false;
            leftVec = Vector2.zero;
            rightVec = Vector2.zero;

            int count = Input.touchCount;
            for (int i = 0; i < count; i++)
            {
                Touch t = Input.GetTouch(i);
                Vector2 g = new Vector2(t.position.x, Screen.height - t.position.y);

                switch (t.phase)
                {
                    case TouchPhase.Began:
                        if (PauseRect.Contains(g))
                        {
                            GameManager.I.TogglePause();
                            continue;
                        }
                        if (CamRect.Contains(g))
                        {
                            GameManager.I.Player.ChaseCam = !GameManager.I.Player.ChaseCam;
                            continue;
                        }
                        if (FireRect.Contains(g))
                        {
                            if (fireId < 0)
                            {
                                fireId = t.fingerId;
                                InputState.Fire = true;
                            }
                            continue;
                        }
                        if (BombRect.Contains(g))
                        {
                            InputState.BombQueued = true;
                            continue;
                        }
                        if (g.x < Screen.width * 0.5f)
                        {
                            if (leftId < 0)
                            {
                                leftId = t.fingerId;
                                leftOrigin = g;
                            }
                        }
                        else
                        {
                            if (rightId < 0)
                            {
                                rightId = t.fingerId;
                                rightOrigin = g;
                            }
                        }
                        break;

                    case TouchPhase.Moved:
                    case TouchPhase.Stationary:
                        if (t.fingerId == fireId) InputState.Fire = true;
                        break;

                    case TouchPhase.Ended:
                    case TouchPhase.Canceled:
                        if (t.fingerId == leftId) leftId = -1;
                        if (t.fingerId == rightId) rightId = -1;
                        if (t.fingerId == fireId) fireId = -1;
                        break;
                }

                if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled) continue;

                float radius = 84f * Sc;
                if (t.fingerId == leftId)
                {
                    Vector2 d = (g - leftOrigin) / radius;
                    if (d.magnitude < 0.07f) d = Vector2.zero;
                    leftVec = Vector2.ClampMagnitude(d, 1f);
                    InputState.Move = new Vector2(leftVec.x, -leftVec.y);
                }
                if (t.fingerId == rightId)
                {
                    Vector2 d = (g - rightOrigin) / radius;
                    if (d.magnitude < 0.07f) d = Vector2.zero;
                    rightVec = Vector2.ClampMagnitude(d, 1f);
                    InputState.Aim = new Vector2(rightVec.x, -rightVec.y);
                }
            }

            if (fireId >= 0) InputState.Fire = true;
        }

        void EnsureStyle()
        {
            if (label != null && styleH == Screen.height) return;
            styleH = Screen.height;
            float s = Sc;
            font = Resources.Load<Font>("Fonts/Roboto-Regular");
            fontBold = Resources.Load<Font>("Fonts/Roboto-Bold");
            if (font == null)
            {
                try
                {
                    font = Font.CreateDynamicFontFromOSFont(
                        new[] { "Roboto", "Noto Sans", "Droid Sans", "Arial", "Liberation Sans", "DejaVu Sans" },
                        Mathf.RoundToInt(18 * s));
                }
                catch { font = null; }
            }
            if (font == null) font = GUI.skin.font;
            if (fontBold == null) fontBold = font;
            label = new GUIStyle(GUI.skin.label);
            label.font = fontBold;
            label.fontSize = Mathf.RoundToInt(16 * s);
            label.fontStyle = FontStyle.Bold;
            label.alignment = TextAnchor.MiddleCenter;
            label.normal.textColor = Color.white;
            small = new GUIStyle(label);
            small.font = font;
            small.fontSize = Mathf.RoundToInt(12 * s);
            small.fontStyle = FontStyle.Normal;
        }

        void OnGUI()
        {
            if (!Active) return;
            GUI.depth = 4;
            EnsureStyle();
            float s = Sc;

            DrawCircle(PauseRect, new Color(0f, 0f, 0f, 0.38f));
            GUI.Label(PauseRect, "II", label);

            DrawCircle(CamRect, new Color(0f, 0f, 0f, 0.38f));
            GUI.Label(CamRect, "ВИД", small);

            DrawCircle(FireRect, InputState.Fire ? new Color(1f, 0.2f, 0.12f, 0.55f) : new Color(0.8f, 0.12f, 0.08f, 0.34f));
            GUI.Label(new Rect(FireRect.x, FireRect.y + FireRect.height * 0.30f, FireRect.width, 30 * s), "ОГОНЬ", label);
            var player = GameManager.I.Player;
            if (player != null)
                GUI.Label(new Rect(FireRect.x, FireRect.y + FireRect.height * 0.58f, FireRect.width, 24 * s), "x" + player.Ammo, small);

            DrawCircle(BombRect, new Color(1f, 0.55f, 0.12f, 0.38f));
            GUI.Label(new Rect(BombRect.x, BombRect.y + BombRect.height * 0.24f, BombRect.width, 26 * s), "БОМБА", label);
            if (player != null)
                GUI.Label(new Rect(BombRect.x, BombRect.y + BombRect.height * 0.54f, BombRect.width, 22 * s), "x" + player.Bombs, small);

            if (leftId >= 0) DrawStick(leftOrigin, leftVec, "ТЯГА / РЫСК");
            if (rightId >= 0) DrawStick(rightOrigin, rightVec, "ТАНГАЖ / КРЕН");
        }

        void DrawStick(Vector2 origin, Vector2 vec, string text)
        {
            float s = Sc;
            float radius = 84f * s;
            Rect baseRect = new Rect(origin.x - radius, origin.y - radius, radius * 2f, radius * 2f);
            DrawCircle(baseRect, new Color(0f, 0f, 0f, 0.30f));
            Vector2 knob = new Vector2(origin.x + vec.x * radius, origin.y - vec.y * radius);
            Rect knobRect = new Rect(knob.x - 34 * s, knob.y - 34 * s, 68 * s, 68 * s);
            DrawCircle(knobRect, new Color(1f, 0.72f, 0.35f, 0.55f));
            GUI.Label(new Rect(origin.x - 110 * s, origin.y + radius + 6 * s, 220 * s, 22 * s), text, small);
        }

        void DrawCircle(Rect r, Color c)
        {
            GUI.color = c;
            GUI.DrawTexture(r, WorldAssets.SoftTex, ScaleMode.StretchToFill, true);
            GUI.color = Color.white;
        }
    }
}
