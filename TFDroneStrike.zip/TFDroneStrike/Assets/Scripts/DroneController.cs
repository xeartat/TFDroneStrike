using UnityEngine;

namespace TF
{
    [RequireComponent(typeof(Rigidbody))]
    public class DroneController : MonoBehaviour, IDamageable
    {
        public static DroneController I;

        public Rigidbody Body;
        public Camera Cam;
        public Transform VisualRoot;
        public Transform CamPivot;

        public Vector3 SpawnPoint;
        public float Health = 100f;
        public float Battery = 100f;
        public int Bombs = 4;
        public int Ammo = 400;
        public bool Dead { get; private set; }
        public float RespawnTimer;
        public float SpeedKmh;
        public float Altitude;
        public float DamageFlash;
        public float ShakeAmount;
        public bool ChaseCam;
        public bool BoundaryWarning;
        public bool Reloading;
        public float ReloadTimer;
        public string LastDeathReason = "";

        public float MaxThrust = 20.5f;
        public float PitchRate = 100f;
        public float RollRate = 165f;
        public float YawRate = 85f;
        public bool LevelAssist = true;

        public float NormalizedHealth { get { return Mathf.Clamp01(Health / 100f); } }
        public float NormalizedBattery { get { return Mathf.Clamp01(Battery / 100f); } }
        public bool IsAlive { get { return !Dead; } }

        float pitchIn, rollIn, yawIn, throttleIn, throttle;
        float nextFire;
        float nextBomb;
        float batteryWarnAt;
        float boundaryWarnAt;
        float rearmFeedAt;
        AudioSource motor;
        AudioSource wind;
        Collider bodyCol;

        public static DroneController Create(Vector3 spawn)
        {
            var go = new GameObject("TF-Дрон");
            go.layer = 2;
            var rb = go.AddComponent<Rigidbody>();
            rb.mass = 1.35f;
            rb.drag = 0.10f;
            rb.angularDrag = 2.0f;
            rb.useGravity = true;
            rb.interpolation = RigidbodyInterpolation.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            var box = go.AddComponent<BoxCollider>();
            box.center = Vector3.zero;
            box.size = new Vector3(0.48f, 0.18f, 0.62f);
            var dc = go.AddComponent<DroneController>();
            dc.SpawnPoint = spawn;
            dc.BuildVisual();
            dc.BuildCamera();
            go.transform.position = spawn;
            go.transform.rotation = Quaternion.identity;
            U.SetLayerRecursive(go, 2);
            return dc;
        }

        void Awake()
        {
            I = this;
            Body = GetComponent<Rigidbody>();
            bodyCol = GetComponent<Collider>();
        }

        void OnDestroy()
        {
            if (I == this) I = null;
        }

        void BuildVisual()
        {
            var v = new GameObject("Модель").transform;
            v.SetParent(transform, false);
            VisualRoot = v;

            U.BoxL(v, "Корпус", new Vector3(0f, 0f, 0f), new Vector3(0.46f, 0.12f, 0.62f), WorldAssets.Dark, null, false);
            U.BoxL(v, "Камера", new Vector3(0f, 0.035f, 0.34f), new Vector3(0.22f, 0.15f, 0.20f), WorldAssets.DarkMetal, null, false);
            U.SphereL(v, "Объектив", new Vector3(0f, 0.035f, 0.455f), Vector3.one * 0.13f, WorldAssets.Glass, false);
            U.SphereL(v, "LED-перед", new Vector3(0f, 0.075f, 0.26f), Vector3.one * 0.045f, WorldAssets.LedRed, false);
            U.SphereL(v, "LED-зад", new Vector3(0f, 0.075f, -0.28f), Vector3.one * 0.045f, WorldAssets.LedGreen, false);
            U.CylL(v, "Антенна", new Vector3(-0.16f, 0.12f, -0.26f), 0.025f, 0.45f, WorldAssets.Dark, Quaternion.Euler(-20f, 0f, 0f), false);

            Vector3[] dirs =
            {
                new Vector3(1f, 0f, 1f), new Vector3(1f, 0f, -1f),
                new Vector3(-1f, 0f, 1f), new Vector3(-1f, 0f, -1f)
            };
            for (int i = 0; i < dirs.Length; i++)
            {
                Vector3 d = dirs[i].normalized;
                Quaternion rot = Quaternion.LookRotation(d, Vector3.up);
                U.BoxL(v, "Луч", d * 0.23f + Vector3.up * 0.02f, new Vector3(0.055f, 0.035f, 0.55f), WorldAssets.Dark, rot, false);
                Vector3 mp = d * 0.47f + Vector3.up * 0.045f;
                U.CylL(v, "Мотор", mp, 0.14f, 0.09f, WorldAssets.DarkMetal, null, false);
                var prop = new GameObject("Пропеллер").transform;
                prop.SetParent(v, false);
                prop.localPosition = mp + Vector3.up * 0.075f;
                U.BoxL(prop, "Лопасть-1", Vector3.zero, new Vector3(0.40f, 0.008f, 0.035f), WorldAssets.Dark, null, false);
                U.BoxL(prop, "Лопасть-2", Vector3.zero, new Vector3(0.035f, 0.008f, 0.40f), WorldAssets.Dark, null, false);
                prop.gameObject.AddComponent<Spin>().Setup(Vector3.up, 2300f + i * 110f);
            }
        }

        void BuildCamera()
        {
            var pivot = new GameObject("Камера-пивот").transform;
            pivot.SetParent(transform, false);
            pivot.localPosition = new Vector3(0f, 0.10f, 0.40f);
            pivot.localRotation = Quaternion.Euler(-6f, 0f, 0f);
            CamPivot = pivot;

            var camGo = new GameObject("FPV-Камера");
            camGo.transform.SetParent(pivot, false);
            camGo.tag = "MainCamera";
            Cam = camGo.AddComponent<Camera>();
            Cam.fieldOfView = 98f;
            Cam.nearClipPlane = 0.03f;
            Cam.farClipPlane = 1400f;
            Cam.allowHDR = false;
            Cam.allowMSAA = true;
            Cam.depth = 0;
            if (RenderSettings.skybox != null)
                Cam.clearFlags = CameraClearFlags.Skybox;
            else
            {
                Cam.clearFlags = CameraClearFlags.SolidColor;
                Cam.backgroundColor = new Color(0.55f, 0.68f, 0.82f);
            }
            camGo.AddComponent<AudioListener>();
        }

        void Start()
        {
            AudioSynth.EnsureInit();
            motor = gameObject.AddComponent<AudioSource>();
            motor.clip = AudioSynth.Engine;
            motor.loop = true;
            motor.volume = 0.22f;
            motor.pitch = 0.8f;
            motor.spatialBlend = 0f;
            if (motor.clip != null) motor.Play();

            if (Cam != null)
            {
                wind = Cam.gameObject.AddComponent<AudioSource>();
                wind.clip = AudioSynth.Wind;
                wind.loop = true;
                wind.volume = 0.10f;
                wind.spatialBlend = 0f;
                if (wind.clip != null) wind.Play();
            }
        }

        void Update()
        {
            if (GameManager.I == null) return;

            SpeedKmh = Body != null ? Body.velocity.magnitude * 3.6f : 0f;
            float ground = TerrainBuilder.GetHeight(transform.position.x, transform.position.z);
            Altitude = Mathf.Max(0f, transform.position.y - Mathf.Max(0f, ground));
            DamageFlash = Mathf.MoveTowards(DamageFlash, 0f, Time.deltaTime * 1.7f);
            ShakeAmount = Mathf.MoveTowards(ShakeAmount, 0f, Time.deltaTime * 2.4f);

            UpdateCamera();

            if (GameManager.I.Paused) return;

            if (Dead)
            {
                RespawnTimer -= Time.deltaTime;
                if (RespawnTimer <= 0f) Respawn();
                return;
            }

            if (!GameManager.I.Started) return;

            if (Battery > 0f)
            {
                Battery = Mathf.Max(0f, Battery - (0.05f + throttle * 0.22f) * Time.deltaTime);
                if (Battery < 15f && Time.time > batteryWarnAt)
                {
                    batteryWarnAt = Time.time + 12f;
                    GameManager.I.Feed("НИЗКИЙ ЗАРЯД БАТАРЕИ", new Color(1f, 0.65f, 0.2f));
                }
                if (Battery <= 0f && Time.time > batteryWarnAt)
                {
                    batteryWarnAt = Time.time + 15f;
                    GameManager.I.Feed("БАТАРЕЯ СЕЛА — ПАДЕНИЕ", Color.red);
                }
            }

            Vector3 pos = transform.position;
            float fromBase = Vector3.Distance(pos, SpawnPoint);
            if (fromBase < 16f && SpeedKmh < 25f)
            {
                Health = Mathf.Min(100f, Health + 18f * Time.deltaTime);
                Battery = Mathf.Min(100f, Battery + 30f * Time.deltaTime);
                if (Time.time > rearmFeedAt)
                {
                    rearmFeedAt = Time.time + 12f;
                    Bombs = 4;
                    Ammo = 400;
                    Reloading = false;
                    GameManager.I.Feed("ПЕРЕВООРУЖЕНИЕ НА БАЗЕ", new Color(0.45f, 1f, 0.45f));
                    AudioSynth.Play2D(AudioSynth.Click, 0.35f, 1.2f);
                }
            }

            if (Input.GetKeyDown(KeyCode.C)) ChaseCam = !ChaseCam;

            if (Reloading)
            {
                ReloadTimer -= Time.deltaTime;
                if (ReloadTimer <= 0f)
                {
                    Reloading = false;
                    Ammo = 400;
                    GameManager.I.Feed("ПУЛЕМЁТ ПЕРЕЗАРЯЖЕН", new Color(0.8f, 0.9f, 1f));
                }
            }

            if (Input.GetKey(KeyCode.Space) || InputState.Fire)
                FireGun();

            if (Input.GetKeyDown(KeyCode.B) || InputState.BombQueued)
            {
                DropBomb();
                InputState.BombQueued = false;
            }

            bool inBoundary = Mathf.Abs(pos.x) > 372f || Mathf.Abs(pos.z) > 372f;
            BoundaryWarning = inBoundary;
            if (inBoundary && Time.time > boundaryWarnAt)
            {
                boundaryWarnAt = Time.time + 4f;
                GameManager.I.Feed("ВЫХОД ИЗ ЗОНЫ — ВОЗВРАЩАЙСЯ", new Color(1f, 0.55f, 0.2f));
            }

            if (motor != null)
            {
                motor.pitch = 0.74f + throttle * 0.55f;
                motor.volume = 0.16f + throttle * 0.22f;
            }
            if (wind != null)
            {
                wind.volume = Mathf.Clamp01(0.06f + SpeedKmh / 900f);
                wind.pitch = 0.9f + Mathf.Clamp01(SpeedKmh / 220f) * 0.35f;
            }
        }

        void FixedUpdate()
        {
            if (Body == null || GameManager.I == null) return;
            if (Dead || !GameManager.I.Started || GameManager.I.Paused) return;

            float kbPitch = (Input.GetKey(KeyCode.W) ? 1f : 0f) - (Input.GetKey(KeyCode.S) ? 1f : 0f);
            float kbRoll = (Input.GetKey(KeyCode.D) ? 1f : 0f) - (Input.GetKey(KeyCode.A) ? 1f : 0f);
            float kbYaw = (Input.GetKey(KeyCode.E) ? 1f : 0f) - (Input.GetKey(KeyCode.Q) ? 1f : 0f);
            float kbThr = (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift) ? 1f : 0f)
                - (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl) ? 1f : 0f);

            pitchIn = Mathf.Clamp(InputState.Aim.y + kbPitch, -1f, 1f);
            rollIn = Mathf.Clamp(InputState.Aim.x + kbRoll, -1f, 1f);
            yawIn = Mathf.Clamp(InputState.Move.x + kbYaw, -1f, 1f);
            throttleIn = Mathf.Clamp(InputState.Move.y + kbThr, -1f, 1f);

            float wanted = Mathf.Clamp01(0.5f + throttleIn * 0.5f);
            throttle = Mathf.Lerp(throttle, wanted, 1f - Mathf.Exp(-7f * Time.fixedDeltaTime));

            if (Battery > 0f)
                Body.AddForce(transform.up * (throttle * MaxThrust), ForceMode.Acceleration);

            Vector3 targetAV = new Vector3(pitchIn * PitchRate, yawIn * YawRate, -rollIn * RollRate) * Mathf.Deg2Rad;
            Vector3 localAV = transform.InverseTransformDirection(Body.angularVelocity);
            Vector3 err = targetAV - localAV;
            Body.AddRelativeTorque(new Vector3(err.x * 6.2f, err.y * 4.0f, err.z * 6.2f), ForceMode.Acceleration);

            if (LevelAssist)
            {
                float level = Mathf.Lerp(5.5f, 1.2f, Mathf.Max(Mathf.Abs(pitchIn), Mathf.Abs(rollIn)));
                Body.AddTorque(Vector3.Cross(transform.up, Vector3.up) * level, ForceMode.Acceleration);
            }

            if (Mathf.Abs(throttleIn) < 0.08f && Battery > 0f)
                Body.AddForce(Vector3.up * (-Body.velocity.y * 0.75f), ForceMode.Acceleration);

            Vector3 hv = new Vector3(Body.velocity.x, 0f, Body.velocity.z);
            Body.AddForce(-hv * 0.018f, ForceMode.Acceleration);
            if (hv.magnitude > 62f)
            {
                hv = hv.normalized * 62f;
                Body.velocity = new Vector3(hv.x, Body.velocity.y, hv.z);
            }

            Vector3 pos = transform.position;
            if (Mathf.Abs(pos.x) > 372f || Mathf.Abs(pos.z) > 372f)
            {
                Vector3 inward = new Vector3(-pos.x, 0f, -pos.z);
                inward.y = 0f;
                if (inward.sqrMagnitude > 0.1f)
                    Body.AddForce(inward.normalized * 11f, ForceMode.Acceleration);
            }
        }

        void UpdateCamera()
        {
            if (CamPivot == null || Cam == null) return;
            Vector3 basePos = ChaseCam ? new Vector3(0f, 1.25f, -3.8f) : new Vector3(0f, 0.10f, 0.40f);
            Quaternion baseRot = Quaternion.Euler(ChaseCam ? 9f : -6f, 0f, 0f);
            float t = Time.time * 41f;
            float shake = ShakeAmount * (ChaseCam ? 0.24f : 0.10f);
            Vector3 jitter = new Vector3(
                (Mathf.PerlinNoise(t, 0.3f) - 0.5f) * shake,
                (Mathf.PerlinNoise(0.7f, t) - 0.5f) * shake,
                0f);
            float rollShake = (Mathf.PerlinNoise(t, 1.7f) - 0.5f) * ShakeAmount * (ChaseCam ? 10f : 5f);
            CamPivot.localPosition = basePos + jitter;
            CamPivot.localRotation = baseRot * Quaternion.Euler(jitter.y * 130f, jitter.x * 130f, rollShake);

            float targetFov = ChaseCam ? 72f : (96f + Mathf.Clamp01(SpeedKmh / 220f) * 10f);
            Cam.fieldOfView = Mathf.Lerp(Cam.fieldOfView, targetFov, Time.deltaTime * 4f);
        }

        void FireGun()
        {
            if (Dead || !GameManager.I.Started || GameManager.I.Paused) return;
            if (Reloading || Time.time < nextFire) return;
            if (Ammo <= 0)
            {
                StartReload();
                return;
            }
            Ammo--;
            nextFire = Time.time + 0.075f;

            Vector3 origin = Cam.transform.position;
            Vector3 dir = Cam.transform.forward;
            dir += Cam.transform.right * Random.Range(-0.006f, 0.006f);
            dir += Cam.transform.up * Random.Range(-0.006f, 0.006f);
            dir.Normalize();

            Vector3 hitPoint = origin + dir * 900f;
            RaycastHit hit;
            if (Physics.Raycast(origin, dir, out hit, 900f, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Collide))
            {
                hitPoint = hit.point;
                var dmg = hit.collider != null ? hit.collider.GetComponentInParent<IDamageable>() : null;
                if (dmg != null && dmg.IsAlive)
                {
                    dmg.TakeDamage(9f, hit.point);
                    if (HUD.I != null) HUD.I.HitMarker();
                }
                FX.Impact(hit.point, hit.normal, hit.collider != null && hit.collider.GetComponentInParent<IDamageable>() != null);
            }

            Vector3 muzzle = origin + Cam.transform.forward * 0.55f + Cam.transform.right * 0.18f - Cam.transform.up * 0.10f;
            FX.Tracer(muzzle, hitPoint);
            FX.Muzzle(muzzle);
            AudioSynth.Play(AudioSynth.Gun, origin, 0.34f, Random.Range(0.93f, 1.07f), 300f);

            if (Ammo <= 0) StartReload();
        }

        void StartReload()
        {
            if (Reloading) return;
            Reloading = true;
            ReloadTimer = 2.9f;
            if (GameManager.I != null) GameManager.I.Feed("ПЕРЕЗАРЯДКА...", new Color(1f, 0.85f, 0.4f));
        }

        void DropBomb()
        {
            if (Dead || !GameManager.I.Started || GameManager.I.Paused) return;
            if (Bombs <= 0 || Time.time < nextBomb) return;
            Bombs--;
            nextBomb = Time.time + 0.4f;
            Vector3 p = transform.position + Vector3.down * 0.35f;
            Bomb.Spawn(p, Body.velocity + Vector3.down * 2f + transform.forward * 1.5f, this);
            if (GameManager.I != null) GameManager.I.Feed("БОМБА СБРОШЕНА", new Color(1f, 0.85f, 0.3f));
        }

        public void AddShake(float amount)
        {
            ShakeAmount = Mathf.Clamp01(ShakeAmount + amount);
        }

        public void TakeDamage(float amount, Vector3 point)
        {
            if (Dead) return;
            Health -= amount;
            DamageFlash = Mathf.Clamp01(DamageFlash + 0.55f);
            AddShake(0.30f);
            if (Health <= 0f) Die("ДРОН УНИЧТОЖЕН");
        }

        void Die(string reason)
        {
            if (Dead) return;
            Dead = true;
            LastDeathReason = reason;
            RespawnTimer = 3.2f;
            if (GameManager.I != null) GameManager.I.OnPlayerDown(reason);
            FX.Explosion(transform.position, 1.45f);
            Combat.Blast(transform.position, 9f, 240f, this);
            Body.velocity = Vector3.zero;
            Body.angularVelocity = Vector3.zero;
            Body.isKinematic = true;
            if (VisualRoot != null) VisualRoot.gameObject.SetActive(false);
            if (motor != null) motor.Stop();
            InputState.ResetAll();
        }

        void Respawn()
        {
            Dead = false;
            LastDeathReason = "";
            Health = 100f;
            Battery = 100f;
            Bombs = 4;
            Ammo = 400;
            Reloading = false;
            DamageFlash = 0f;
            ShakeAmount = 0f;
            throttle = 0f;
            Vector3 p = SpawnPoint;
            transform.SetPositionAndRotation(p, Quaternion.identity);
            Body.isKinematic = false;
            Body.position = p;
            Body.velocity = Vector3.zero;
            Body.angularVelocity = Vector3.zero;
            if (VisualRoot != null) VisualRoot.gameObject.SetActive(true);
            if (motor != null) motor.Play();
            if (GameManager.I != null) GameManager.I.Feed("НОВЫЙ ДРОН НА БАЗЕ", new Color(0.45f, 1f, 0.45f));
        }

        void OnCollisionEnter(Collision collision)
        {
            if (Dead || GameManager.I == null || !GameManager.I.Started || GameManager.I.Paused) return;
            float speed = collision.relativeVelocity.magnitude;
            if (speed < 3f) return;
            Vector3 point = collision.contactCount > 0 ? collision.GetContact(0).point : transform.position;
            var dmg = collision.collider != null ? collision.collider.GetComponentInParent<IDamageable>() : null;

            if (speed > 8f)
            {
                if (dmg != null && dmg.IsAlive) dmg.TakeDamage(300f, point);
                Die("ТАРАН");
            }
            else
            {
                TakeDamage((speed - 3f) * 7.5f, point);
            }
        }
    }
}
