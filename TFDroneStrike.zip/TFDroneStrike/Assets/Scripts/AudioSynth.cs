using UnityEngine;

namespace TF
{
    public static class AudioSynth
    {
        public static AudioClip Boom, Gun, Click, Engine, Wind, Alarm, Missile;
        static bool init;

        public static void EnsureInit()
        {
            if (init) return;
            init = true;
            int sr = AudioSettings.outputSampleRate;
            if (sr <= 0) sr = 48000;

            var rng = new System.Random(90210);
            float lp = 0f;
            Boom = Make("Взрыв", 1.7f, sr, t =>
            {
                float n = (float)rng.NextDouble() * 2f - 1f;
                lp += (n - lp) * 0.045f;
                float env = Mathf.Exp(-t * 2.4f);
                float crack = t < 0.045f ? ((float)rng.NextDouble() * 2f - 1f) * 0.55f : 0f;
                return (lp * 1.55f + Mathf.Sin(t * 54f) * 0.55f * Mathf.Exp(-t * 5f) + crack) * env;
            });

            rng = new System.Random(7731);
            lp = 0f;
            Gun = Make("Выстрел", 0.14f, sr, t =>
            {
                float n = (float)rng.NextDouble() * 2f - 1f;
                lp += (n - lp) * 0.65f;
                float k = Mathf.Exp(-t * 36f);
                return ((n - lp) * 0.9f + Mathf.Sin(t * 1400f) * 0.12f) * k;
            });

            rng = new System.Random(1);
            Click = Make("Щелчок", 0.09f, sr, t =>
            {
                float env = Mathf.Exp(-t * 55f);
                return (Mathf.Sin(t * 1050f) * 0.45f + Mathf.Sin(t * 2600f) * 0.15f) * env;
            });

            Engine = Make("Мотор", 1.0f, sr, t =>
            {
                float s = Mathf.Sin(t * Mathf.PI * 2f * 68f) * 0.26f;
                s += Mathf.Sin(t * Mathf.PI * 2f * 136f + 0.7f) * 0.18f;
                s += Mathf.Sin(t * Mathf.PI * 2f * 272f + 1.4f) * 0.11f;
                s += Mathf.Sin(t * Mathf.PI * 2f * 780f + 0.2f) * 0.045f;
                s *= 0.78f + 0.22f * Mathf.Sin(t * Mathf.PI * 2f * 12f);
                return s;
            });

            Wind = Make("Ветер", 2.0f, sr, t =>
            {
                float s = Mathf.Sin(t * Mathf.PI * 2f * 0.5f + 0.2f) * 0.12f;
                s += Mathf.Sin(t * Mathf.PI * 2f * 1.5f + 1.1f) * 0.08f;
                s += Mathf.Sin(t * Mathf.PI * 2f * 3.0f + 2.2f) * 0.05f;
                s += Mathf.Sin(t * Mathf.PI * 2f * 5.5f + 0.6f) * 0.025f;
                return s;
            });

            Alarm = Make("Тревога", 1.25f, sr, t =>
            {
                float phase = t % 0.42f;
                float env = phase < 0.20f ? Mathf.Sin(phase / 0.20f * Mathf.PI) : 0f;
                return Mathf.Sin(t * Mathf.PI * 2f * 980f) * env * 0.32f;
            });

            rng = new System.Random(4455);
            lp = 0f;
            Missile = Make("Ракета", 1.5f, sr, t =>
            {
                float n = (float)rng.NextDouble() * 2f - 1f;
                lp += (n - lp) * 0.09f;
                float env = Mathf.Sin(Mathf.Clamp01(t / 1.5f) * Mathf.PI);
                return (lp * 1.2f + Mathf.Sin(t * Mathf.PI * 2f * (95f + t * 80f)) * 0.18f) * env * 0.7f;
            });
        }

        static AudioClip Make(string name, float duration, int sampleRate, System.Func<float, float> sample)
        {
            int count = Mathf.Max(1, Mathf.RoundToInt(duration * sampleRate));
            var data = new float[count];
            for (int i = 0; i < count; i++)
            {
                float t = i / (float)sampleRate;
                float s = sample(t);
                if (float.IsNaN(s) || float.IsInfinity(s)) s = 0f;
                data[i] = Mathf.Clamp(s, -1f, 1f);
            }
            var clip = AudioClip.Create(name, count, 1, sampleRate, false);
            clip.SetData(data, 0);
            return clip;
        }

        public static void Play(AudioClip clip, Vector3 pos, float volume, float pitch, float maxDistance)
        {
            if (clip == null) return;
            var go = new GameObject("Звук");
            go.transform.position = pos;
            var src = go.AddComponent<AudioSource>();
            src.clip = clip;
            src.volume = Mathf.Clamp01(volume);
            src.pitch = Mathf.Clamp(pitch, 0.35f, 2.2f);
            src.spatialBlend = 0.8f;
            src.rolloffMode = AudioRolloffMode.Linear;
            src.minDistance = 3f;
            src.maxDistance = Mathf.Max(10f, maxDistance);
            src.dopplerLevel = 0.4f;
            src.Play();
            Object.Destroy(go, clip.length / Mathf.Max(0.3f, src.pitch) + 0.3f);
        }

        public static void Play2D(AudioClip clip, float volume, float pitch)
        {
            if (clip == null) return;
            var go = new GameObject("Звук-UI");
            var src = go.AddComponent<AudioSource>();
            src.clip = clip;
            src.volume = Mathf.Clamp01(volume);
            src.pitch = Mathf.Clamp(pitch, 0.4f, 2f);
            src.spatialBlend = 0f;
            src.Play();
            Object.Destroy(go, clip.length / Mathf.Max(0.3f, src.pitch) + 0.25f);
        }
    }
}
