using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TF
{
    public enum TargetKind
    {
        Vehicle,
        Infantry,
        Bunker,
        Depot,
        Radar
    }

    public class Target : MonoBehaviour, IDamageable
    {
        public static readonly List<Target> All = new List<Target>();

        public TargetKind Kind = TargetKind.Vehicle;
        public string Label = "ЦЕЛЬ";
        public float Health = 100f;
        public int Score = 100;

        public bool Destroyed { get; private set; }
        public bool IsAlive { get { return !Destroyed; } }

        Bounds cachedBounds;
        bool hasBounds;

        public static int AliveCount
        {
            get
            {
                int c = 0;
                for (int i = 0; i < All.Count; i++)
                    if (All[i] != null && !All[i].Destroyed) c++;
                return c;
            }
        }

        public Bounds Bounds
        {
            get
            {
                if (hasBounds) return cachedBounds;
                hasBounds = true;
                var rs = GetComponentsInChildren<Renderer>();
                if (rs.Length == 0)
                {
                    cachedBounds = new Bounds(transform.position + Vector3.up, Vector3.one * 2f);
                    return cachedBounds;
                }
                cachedBounds = rs[0].bounds;
                for (int i = 1; i < rs.Length; i++) cachedBounds.Encapsulate(rs[i].bounds);
                return cachedBounds;
            }
        }

        public Vector3 Center
        {
            get { return Bounds.center; }
        }

        void Awake()
        {
            All.Add(this);
        }

        void OnDestroy()
        {
            All.Remove(this);
        }

        public void TakeDamage(float amount, Vector3 point)
        {
            if (Destroyed) return;
            Health -= amount;
            FX.Impact(point, Vector3.up, Kind == TargetKind.Vehicle || Kind == TargetKind.Bunker || Kind == TargetKind.Radar);
            if (Health <= 0f) Die();
        }

        void Die()
        {
            if (Destroyed) return;
            Destroyed = true;
            if (GameManager.I != null) GameManager.I.OnTargetDestroyed(this);

            Vector3 c = Center;
            float scale = Kind == TargetKind.Bunker ? 2.1f : (Kind == TargetKind.Depot ? 1.7f : (Kind == TargetKind.Infantry ? 0.7f : 1.3f));
            FX.Explosion(c, scale);

            if (Kind == TargetKind.Infantry)
            {
                Destroy(gameObject, 0.08f);
                return;
            }

            StartCoroutine(SecondaryExplosions());
            TurnIntoWreck();
        }

        IEnumerator SecondaryExplosions()
        {
            yield return new WaitForSeconds(0.22f);
            if (this == null) yield break;
            FX.Explosion(Center + Random.insideUnitSphere * 2.2f, 0.85f);
            yield return new WaitForSeconds(0.4f);
            if (this == null) yield break;
            FX.Explosion(Center + Random.insideUnitSphere * 3.0f, 0.7f);
        }

        void TurnIntoWreck()
        {
            var rs = GetComponentsInChildren<Renderer>();
            var mpb = new MaterialPropertyBlock();
            for (int i = 0; i < rs.Length; i++)
            {
                if (rs[i] == null) continue;
                rs[i].GetPropertyBlock(mpb);
                mpb.SetColor("_Color", new Color(0.09f, 0.085f, 0.08f, 1f));
                rs[i].SetPropertyBlock(mpb);
            }
            FX.WreckSmoke(transform, 16f);
            StartCoroutine(RemoveLater());
        }

        IEnumerator RemoveLater()
        {
            yield return new WaitForSeconds(45f);
            if (this != null) Destroy(gameObject);
        }
    }
}
