using System.Collections.Generic;
using UnityEngine;

namespace TF
{
    public interface IDamageable
    {
        bool IsAlive { get; }
        void TakeDamage(float amount, Vector3 point);
    }

    public static class InputState
    {
        public static Vector2 Move;
        public static Vector2 Aim;
        public static bool Fire;
        public static bool BombQueued;

        public static void ClearButtons()
        {
            Fire = false;
            BombQueued = false;
        }

        public static void ResetAll()
        {
            Move = Vector2.zero;
            Aim = Vector2.zero;
            Fire = false;
            BombQueued = false;
        }
    }

    public static class U
    {
        public static GameObject Box(Transform parent, string name, Vector3 worldPos, Vector3 size, Material mat, Quaternion rot, bool collider = true)
        {
            return Prim(PrimitiveType.Cube, parent, name, worldPos, size, mat, rot, collider, false);
        }

        public static GameObject BoxL(Transform parent, string name, Vector3 localPos, Vector3 size, Material mat, Quaternion? rot = null, bool collider = false)
        {
            return Prim(PrimitiveType.Cube, parent, name, localPos, size, mat, rot ?? Quaternion.identity, collider, true);
        }

        public static GameObject Sphere(Transform parent, string name, Vector3 worldPos, float diameter, Material mat, bool collider = true)
        {
            return Prim(PrimitiveType.Sphere, parent, name, worldPos, Vector3.one * diameter, mat, Quaternion.identity, collider, false);
        }

        public static GameObject SphereL(Transform parent, string name, Vector3 localPos, Vector3 scale, Material mat, bool collider = false)
        {
            return Prim(PrimitiveType.Sphere, parent, name, localPos, scale, mat, Quaternion.identity, collider, true);
        }

        public static GameObject Cyl(Transform parent, string name, Vector3 worldPos, float diameter, float height, Material mat, Quaternion rot, bool collider = true)
        {
            return Prim(PrimitiveType.Cylinder, parent, name, worldPos, new Vector3(diameter, height * 0.5f, diameter), mat, rot, collider, false);
        }

        public static GameObject CylL(Transform parent, string name, Vector3 localPos, float diameter, float height, Material mat, Quaternion? rot = null, bool collider = false)
        {
            return Prim(PrimitiveType.Cylinder, parent, name, localPos, new Vector3(diameter, height * 0.5f, diameter), mat, rot ?? Quaternion.identity, collider, true);
        }

        static GameObject Prim(PrimitiveType type, Transform parent, string name, Vector3 pos, Vector3 scale, Material mat, Quaternion rot, bool collider, bool local)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            if (!collider)
            {
                var c = go.GetComponent<Collider>();
                if (c != null) Object.Destroy(c);
            }
            var t = go.transform;
            if (parent != null) t.SetParent(parent, false);
            if (local)
            {
                t.localPosition = pos;
                t.localRotation = rot;
            }
            else
            {
                t.position = pos;
                t.rotation = rot;
            }
            t.localScale = scale;
            var r = go.GetComponent<Renderer>();
            if (r != null && mat != null) r.sharedMaterial = mat;
            return go;
        }

        public static void SetLayerRecursive(GameObject go, int layer)
        {
            go.layer = layer;
            for (int i = 0; i < go.transform.childCount; i++)
                SetLayerRecursive(go.transform.GetChild(i).gameObject, layer);
        }

        public static void KillColliders(GameObject go)
        {
            var colliders = go.GetComponentsInChildren<Collider>();
            for (int i = 0; i < colliders.Length; i++) Object.Destroy(colliders[i]);
        }

        public static Quaternion Yaw(float degrees)
        {
            return Quaternion.Euler(0f, degrees, 0f);
        }

        public static Color RGB(float r, float g, float b)
        {
            return new Color(r, g, b, 1f);
        }
    }

    public static class Combat
    {
        public static void Blast(Vector3 center, float radius, float damage, Component source)
        {
            Collider[] hits = Physics.OverlapSphere(center, radius, ~0, QueryTriggerInteraction.Collide);
            var seen = new HashSet<IDamageable>();
            for (int i = 0; i < hits.Length; i++)
            {
                var col = hits[i];
                if (col == null) continue;
                var dmg = col.GetComponentInParent<IDamageable>();
                if (dmg == null || !dmg.IsAlive) continue;
                if (source != null)
                {
                    if (object.ReferenceEquals(dmg, source)) continue;
                    var dmgComp = dmg as Component;
                    if (dmgComp != null && dmgComp.transform.IsChildOf(source.transform)) continue;
                    if (dmgComp != null && source.transform.IsChildOf(dmgComp.transform)) continue;
                }
                if (!seen.Add(dmg)) continue;
                Vector3 p = col.bounds.ClosestPoint(center);
                float dist = Vector3.Distance(center, p);
                float falloff = Mathf.Clamp01(1f - dist / Mathf.Max(0.01f, radius));
                if (falloff <= 0.01f) continue;
                dmg.TakeDamage(damage * falloff, p);
            }

            for (int i = 0; i < hits.Length; i++)
            {
                var col = hits[i];
                if (col == null) continue;
                var rb = col.attachedRigidbody;
                if (rb == null || rb.isKinematic) continue;
                if (source != null && rb.transform == source.transform) continue;
                rb.AddExplosionForce(damage * 3f, center, radius, 0.8f, ForceMode.VelocityChange);
            }
        }
    }
}
