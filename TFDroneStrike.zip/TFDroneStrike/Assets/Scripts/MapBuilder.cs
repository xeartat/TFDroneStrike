using System.Collections.Generic;
using UnityEngine;

namespace TF
{
    public class MapBuilder : MonoBehaviour
    {
        public static MapBuilder I;

        public Vector3 PlayerSpawn;
        TerrainBuilder T;
        Transform root;
        readonly List<Vector2> vehicleSites = new List<Vector2>();
        int barricadeCounter;

        void Awake()
        {
            I = this;
        }

        void OnDestroy()
        {
            if (I == this) I = null;
        }

        public void BuildAll(Transform world)
        {
            root = world;
            T = TerrainBuilder.I;
            vehicleSites.Clear();
            BuildBase();
            BuildVillage();
            BuildTrenchNetwork();
            BuildBunkers();
            BuildVehicles();
            BuildDepot();
            BuildRadarSite();
            BuildTrees();
            BuildPowerLine();
            BuildTurbines();
            BuildClouds();
            BuildWrecks();
        }

        float Y(float x, float z)
        {
            return T != null ? T.Height(x, z) : 0f;
        }

        GameObject Root(string name, Vector3 pos, float yaw)
        {
            var go = new GameObject(name);
            go.transform.SetParent(root, true);
            go.transform.position = pos;
            go.transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            return go;
        }

        Target Mark(GameObject go, TargetKind kind, string label, float health, int score)
        {
            var t = go.AddComponent<Target>();
            t.Kind = kind;
            t.Label = label;
            t.Health = health;
            t.Score = score;
            return t;
        }

        void BuildBase()
        {
            Vector3 pad = new Vector3(T.BaseCenter.x, Y(T.BaseCenter.x, T.BaseCenter.y), T.BaseCenter.y);
            PlayerSpawn = pad + Vector3.up * 0.55f;
            U.Cyl(root, "Площадка", pad + Vector3.up * 0.08f, 9.5f, 0.16f, WorldAssets.Concrete, Quaternion.identity, true);
            U.Box(root, "H1", pad + new Vector3(-1.6f, 0.18f, 0f), new Vector3(0.4f, 0.03f, 4.2f), WorldAssets.White, Quaternion.identity, false);
            U.Box(root, "H2", pad + new Vector3(1.6f, 0.18f, 0f), new Vector3(0.4f, 0.03f, 4.2f), WorldAssets.White, Quaternion.identity, false);
            U.Box(root, "H3", pad + new Vector3(0f, 0.18f, 0f), new Vector3(3.4f, 0.03f, 0.4f), WorldAssets.White, Quaternion.identity, false);

            for (int i = 0; i < 20; i++)
            {
                float a = i / 20f * Mathf.PI * 2f;
                Vector3 p = pad + new Vector3(Mathf.Cos(a) * 6.4f, 0.18f, Mathf.Sin(a) * 6.4f);
                U.Box(root, "Мешок", p, new Vector3(0.85f, 0.35f, 0.5f), WorldAssets.Sandbag, U.Yaw(-a * Mathf.Rad2Deg), false);
            }

            Tent(pad + new Vector3(-13f, 0f, 8f), 12f);
            Tent(pad + new Vector3(13f, 0f, 9f), -20f);
            Tent(pad + new Vector3(-15f, 0f, -8f), 4f);

            Vector3 antenna = pad + new Vector3(12f, 0f, -8f);
            U.Cyl(root, "Антенна", antenna + Vector3.up * 4.5f, 0.22f, 9f, WorldAssets.Metal, Quaternion.identity, true);
            U.Box(root, "Антенна-1", antenna + Vector3.up * 7.2f, new Vector3(2.2f, 0.08f, 0.08f), WorldAssets.Metal, Quaternion.identity, false);
            U.Box(root, "Антенна-2", antenna + Vector3.up * 8.1f, new Vector3(1.4f, 0.08f, 0.08f), WorldAssets.Metal, Quaternion.identity, false);

            Vector3 flag = pad + new Vector3(-10f, 0f, -10f);
            U.Cyl(root, "Флагшток", flag + Vector3.up * 3f, 0.1f, 6f, WorldAssets.Metal, Quaternion.identity, true);
            U.Box(root, "Флаг", flag + new Vector3(1.2f, 5.4f, 0f), new Vector3(2.2f, 1.2f, 0.04f), WorldAssets.LedRed, Quaternion.identity, false);

            var rng = new System.Random(111);
            for (int i = 0; i < 12; i++)
            {
                float a = (float)rng.NextDouble() * Mathf.PI * 2f;
                float r = 9f + (float)rng.NextDouble() * 12f;
                Vector3 p = pad + new Vector3(Mathf.Cos(a) * r, 0f, Mathf.Sin(a) * r);
                p.y = Y(p.x, p.z);
                if (i % 3 == 0)
                    U.Cyl(root, "Бочка", p + Vector3.up * 0.55f, 0.75f, 1.1f, WorldAssets.Rust, Quaternion.identity, false);
                else
                    U.Box(root, "Ящик", p + Vector3.up * 0.3f, new Vector3(0.8f, 0.6f, 0.8f), WorldAssets.Wood, U.Yaw((float)rng.NextDouble() * 90f), false);
            }

            Vector3 windsock = pad + new Vector3(8f, 0f, -14f);
            U.Cyl(root, "Мачта", windsock + Vector3.up * 2.2f, 0.09f, 4.4f, WorldAssets.Metal, Quaternion.identity, false);
            U.Box(root, "Колдун", windsock + new Vector3(1.1f, 4.1f, 0f), new Vector3(2.0f, 0.45f, 0.06f), WorldAssets.LedRed, Quaternion.Euler(0f, 0f, -8f), false);

            U.Box(root, "Бетон-1", pad + new Vector3(-22f, 0.25f, 20f), new Vector3(4f, 0.5f, 0.6f), WorldAssets.Concrete, Quaternion.identity, true);
            U.Box(root, "Бетон-2", pad + new Vector3(-22f, 0.25f, 24f), new Vector3(4f, 0.5f, 0.6f), WorldAssets.Concrete, Quaternion.identity, true);
        }

        void Tent(Vector3 p, float yaw)
        {
            p.y = Y(p.x, p.z);
            var r = Root("Палатка", p, yaw);
            U.BoxL(r.transform, "Тент", new Vector3(0f, 0.9f, 0f), new Vector3(4.6f, 1.8f, 3.4f), WorldAssets.Canvas, null, true);
            U.BoxL(r.transform, "Крыша", new Vector3(0f, 1.95f, 0f), new Vector3(4.9f, 0.16f, 3.7f), WorldAssets.Canvas, null, false);
            U.BoxL(r.transform, "Вход", new Vector3(0f, 0.8f, 1.73f), new Vector3(1.2f, 1.3f, 0.06f), WorldAssets.Dark, null, false);
        }

        void BuildVillage()
        {
            Vector3 c = new Vector3(T.VillageCenter.x, 0f, T.VillageCenter.y);
            var houses = new[]
            {
                new Vector3(-38f, 0f, -22f), new Vector3(-17f, 0f, -24f), new Vector3(8f, 0f, -21f),
                new Vector3(32f, 0f, -18f), new Vector3(46f, 0f, 2f), new Vector3(31f, 0f, 27f),
                new Vector3(5f, 0f, 34f), new Vector3(-23f, 0f, 31f), new Vector3(-44f, 0f, 10f)
            };
            for (int i = 0; i < houses.Length; i++)
            {
                Vector3 p = c + houses[i];
                p.y = Y(p.x, p.z);
                House(p, i * 37f + 5f, i == 2 || i == 6);
            }

            Vector3 entrance = c + new Vector3(-8f, 0f, -52f);
            entrance.y = Y(entrance.x, entrance.z);
            U.Box(root, "Шлагбаум", entrance + new Vector3(0f, 0.25f, 0f), new Vector3(5f, 0.5f, 0.5f), WorldAssets.Concrete, Quaternion.identity, true);
            for (int i = 0; i < 8; i++)
            {
                Vector3 p = entrance + new Vector3(-3f + i * 0.85f, 0.45f, -1.2f);
                U.Box(root, "Мешок", p, new Vector3(0.8f, 0.35f, 0.5f), WorldAssets.Sandbag, Quaternion.identity, false);
            }

            for (int i = 0; i < 5; i++)
            {
                Vector3 p = c + new Vector3(-52f + i * 26f, 0f, 50f);
                p.y = Y(p.x, p.z);
                U.Cyl(root, "Столб", p + Vector3.up * 0.8f, 0.16f, 1.6f, WorldAssets.Wood, Quaternion.identity, false);
                U.Box(root, "Перекладина", p + Vector3.up * 1.4f, new Vector3(0.12f, 0.12f, 26f), WorldAssets.Wood, Quaternion.identity, false);
            }
        }

        void House(Vector3 p, float yaw, bool ruined)
        {
            var r = Root(ruined ? "Разбитый дом" : "Дом", p, yaw);
            if (!ruined)
            {
                U.BoxL(r.transform, "Стены", new Vector3(0f, 1.6f, 0f), new Vector3(6f, 3.2f, 7f), WorldAssets.House, null, true);
                U.BoxL(r.transform, "Крыша-1", new Vector3(0f, 3.7f, -1.85f), new Vector3(6.7f, 0.22f, 4.0f), WorldAssets.Roof, Quaternion.Euler(-24f, 0f, 0f), true);
                U.BoxL(r.transform, "Крыша-2", new Vector3(0f, 3.7f, 1.85f), new Vector3(6.7f, 0.22f, 4.0f), WorldAssets.Roof, Quaternion.Euler(24f, 0f, 0f), true);
                U.BoxL(r.transform, "Труба", new Vector3(1.8f, 4.2f, -1.6f), new Vector3(0.5f, 1.7f, 0.5f), WorldAssets.Concrete, null, false);
                U.BoxL(r.transform, "Дверь", new Vector3(0f, 1.1f, 3.53f), new Vector3(1.15f, 2.2f, 0.08f), WorldAssets.Dark, null, false);
                U.BoxL(r.transform, "Окно-1", new Vector3(-2.0f, 1.8f, 3.52f), new Vector3(1.0f, 1.1f, 0.08f), WorldAssets.Glass, null, false);
                U.BoxL(r.transform, "Окно-2", new Vector3(2.0f, 1.8f, 3.52f), new Vector3(1.0f, 1.1f, 0.08f), WorldAssets.Glass, null, false);
                U.BoxL(r.transform, "Окно-3", new Vector3(3.02f, 1.8f, 0f), new Vector3(0.08f, 1.1f, 1.2f), WorldAssets.Glass, null, false);
            }
            else
            {
                U.BoxL(r.transform, "Стена", new Vector3(-1.3f, 1.0f, 0f), new Vector3(3.2f, 2.0f, 7f), WorldAssets.House, null, true);
                U.BoxL(r.transform, "Обломки", new Vector3(1.0f, 0.45f, 1.2f), new Vector3(2.6f, 0.9f, 4.0f), WorldAssets.Concrete, Quaternion.Euler(4f, 0f, 9f), true);
                for (int i = 0; i < 7; i++)
                {
                    U.BoxL(r.transform, "Кирпич", new Vector3(Random.Range(-2.6f, 2.6f), 0.15f, Random.Range(-3f, 3f)),
                        new Vector3(Random.Range(0.3f, 0.8f), 0.2f, Random.Range(0.3f, 0.7f)), WorldAssets.Roof, Quaternion.Euler(Random.Range(0f, 40f), Random.Range(0f, 360f), 0f), false);
                }
            }

            for (int i = 0; i < 6; i++)
            {
                Vector3 fp = p + r.transform.rotation * new Vector3(-4.2f, 0f, -3.5f + i * 1.4f);
                fp.y = Y(fp.x, fp.z);
                U.Cyl(root, "Штакет", fp + Vector3.up * 0.6f, 0.12f, 1.2f, WorldAssets.Wood, Quaternion.identity, false);
            }
        }

        void BuildTrenchNetwork()
        {
            var segs = T.TrenchSegments;
            for (int s = 0; s < segs.Count; s++)
            {
                var seg = segs[s];
                for (int i = 0; i < seg.Length - 1; i++)
                {
                    Vector2 a = seg[i];
                    Vector2 b = seg[i + 1];
                    Vector2 d = (b - a);
                    float len = d.magnitude;
                    if (len < 0.1f) continue;
                    Vector2 dir = d / len;
                    Vector2 perp = new Vector2(-dir.y, dir.x);
                    float yaw = Mathf.Atan2(dir.x, dir.y) * Mathf.Rad2Deg;

                    for (float t = 1.5f; t < len; t += 3.0f)
                    {
                        Vector2 c = a + dir * t;
                        Vector3 floor = new Vector3(c.x, Y(c.x, c.y), c.y);
                        if (Mathf.RoundToInt(t / 3f) % 2 == 0)
                        {
                            U.Box(root, "Доска", floor + Vector3.up * 0.07f, new Vector3(0.55f, 0.06f, 3.1f), WorldAssets.Wood, U.Yaw(yaw), false);
                        }
                        for (int side = -1; side <= 1; side += 2)
                        {
                            Vector2 o = c + perp * (side * 2.9f);
                            Vector3 sp = new Vector3(o.x, Y(o.x, o.y) + 0.16f, o.y);
                            U.Box(root, "Мешок", sp, new Vector3(0.8f, 0.35f, 0.5f), WorldAssets.Sandbag, U.Yaw(yaw + (side > 0 ? 90f : 90f)), false);
                        }
                    }

                    int idx = 0;
                    for (float t = 5f; t < len - 2f; t += 11f)
                    {
                        Vector2 c = a + dir * t;
                        Vector2 o = c + perp * (idx % 2 == 0 ? -0.65f : 0.65f);
                        Vector3 sp = new Vector3(o.x, Y(o.x, o.y) + 0.05f, o.y);
                        if (idx % 4 == 3)
                            AmmoCrate(sp, yaw);
                        else
                            Soldier(sp, yaw + 180f + (idx % 2 == 0 ? -20f : 20f));
                        idx++;
                    }

                    if (s == 0 && i == 0)
                    {
                        Vector2 g = a + perp * 2.0f;
                        Vector3 gp = new Vector3(g.x, Y(g.x, g.y) + 0.05f, g.y);
                        MachineGunNest(gp, yaw + 90f);
                    }
                }
            }
        }

        void Soldier(Vector3 p, float yaw)
        {
            var r = Root("Пехота", p, yaw);
            U.CylL(r.transform, "Туловище", new Vector3(0f, 0.55f, 0f), 0.46f, 0.95f, WorldAssets.Camo, null, true);
            U.SphereL(r.transform, "Голова", new Vector3(0f, 1.2f, 0f), Vector3.one * 0.34f, WorldAssets.Sandbag, false);
            U.SphereL(r.transform, "Каска", new Vector3(0f, 1.28f, 0f), new Vector3(0.42f, 0.24f, 0.42f), WorldAssets.DarkMetal, false);
            U.BoxL(r.transform, "Ноги", new Vector3(0f, 0.18f, 0f), new Vector3(0.4f, 0.4f, 0.35f), WorldAssets.Camo, null, false);
            U.BoxL(r.transform, "Автомат", new Vector3(0.3f, 0.75f, 0.28f), new Vector3(0.08f, 0.08f, 0.8f), WorldAssets.Dark, null, false);
            Mark(r, TargetKind.Infantry, "ПЕХОТА", 45f, 50);
        }

        void AmmoCrate(Vector3 p, float yaw)
        {
            var r = Root("Боеприпасы", p, yaw);
            U.BoxL(r.transform, "Ящик", new Vector3(0f, 0.37f, 0f), new Vector3(1.1f, 0.7f, 0.75f), WorldAssets.Wood, null, true);
            U.BoxL(r.transform, "Крышка", new Vector3(0f, 0.77f, 0f), new Vector3(1.15f, 0.1f, 0.8f), WorldAssets.Dark, null, false);
            Mark(r, TargetKind.Depot, "БОЕКОМПЛЕКТ", 75f, 80);
        }

        void MachineGunNest(Vector3 p, float yaw)
        {
            var r = Root("Пулемётный расчёт", p, yaw);
            for (int i = 0; i < 9; i++)
            {
                float a = -120f + i * 30f;
                Vector3 q = p + Quaternion.Euler(0f, yaw + a, 0f) * Vector3.forward * 2.0f;
                q.y = Y(q.x, q.z) + 0.16f;
                U.Box(root, "Мешок", q, new Vector3(0.9f, 0.35f, 0.5f), WorldAssets.Sandbag, U.Yaw(yaw + a + 90f), false);
            }
            U.BoxL(r.transform, "Станина", new Vector3(0f, 0.5f, 0f), new Vector3(1.1f, 0.25f, 0.8f), WorldAssets.Dark, null, false);
            U.CylL(r.transform, "Ствол", new Vector3(0f, 0.8f, 0.55f), 0.16f, 1.6f, WorldAssets.DarkMetal, Quaternion.Euler(75f, 0f, 0f), false);
            U.BoxL(r.transform, "Корпус", new Vector3(0f, 0.62f, -0.15f), new Vector3(0.5f, 0.35f, 0.7f), WorldAssets.Dark, null, false);
            Mark(r, TargetKind.Infantry, "ПУЛЕМЁТНЫЙ РАСЧЁТ", 120f, 130);
        }

        void BuildBunkers()
        {
            Bunker(new Vector3(50f, 0f, 9f), 16f, true);
            Bunker(new Vector3(130f, 0f, 143f), -30f, true);
            Bunker(new Vector3(-72f, 0f, 72f), 8f, false);
        }

        void Bunker(Vector3 p, float yaw, bool big)
        {
            p.y = Y(p.x, p.z);
            var r = Root(big ? "Блиндаж" : "ДОТ", p, yaw);
            float w = big ? 9f : 6.5f;
            float d = big ? 7f : 5f;
            float h = big ? 2.5f : 2.0f;
            U.BoxL(r.transform, "Пол", new Vector3(0f, 0.15f, 0f), new Vector3(w, 0.3f, d), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Задняя стена", new Vector3(0f, h * 0.5f + 0.3f, -d * 0.5f + 0.25f), new Vector3(w, h, 0.5f), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Стена-Л", new Vector3(-w * 0.5f + 0.25f, h * 0.5f + 0.3f, 0f), new Vector3(0.5f, h, d), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Стена-П", new Vector3(w * 0.5f - 0.25f, h * 0.5f + 0.3f, 0f), new Vector3(0.5f, h, d), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Фронт-Л", new Vector3(-w * 0.28f, h * 0.5f + 0.3f, d * 0.5f - 0.25f), new Vector3(w * 0.42f, h, 0.5f), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Фронт-П", new Vector3(w * 0.28f, h * 0.5f + 0.3f, d * 0.5f - 0.25f), new Vector3(w * 0.42f, h, 0.5f), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Крыша", new Vector3(0f, h + 0.45f, 0f), new Vector3(w + 0.8f, 0.55f, d + 0.8f), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Вход", new Vector3(0f, 0.55f, d * 0.5f + 0.03f), new Vector3(2.2f, 1.1f, 0.06f), WorldAssets.Dark, null, false);
            U.BoxL(r.transform, "Мешок-1", new Vector3(0f, 0.25f, d * 0.5f + 1.0f), new Vector3(3.6f, 0.5f, 0.8f), WorldAssets.Sandbag, null, false);
            U.BoxL(r.transform, "Мешок-2", new Vector3(-2.4f, 0.25f, d * 0.5f + 1.2f), new Vector3(2.0f, 0.5f, 0.8f), WorldAssets.Sandbag, null, false);
            U.BoxL(r.transform, "Мешок-3", new Vector3(2.3f, 0.25f, d * 0.5f + 1.1f), new Vector3(2.2f, 0.5f, 0.8f), WorldAssets.Sandbag, null, false);
            if (big)
            {
                U.BoxL(r.transform, "Ящик", new Vector3(-2.0f, 0.7f, -1.5f), new Vector3(1.2f, 0.8f, 0.8f), WorldAssets.Wood, null, false);
                U.BoxL(r.transform, "Ящик-2", new Vector3(2.1f, 0.55f, -1.6f), new Vector3(1.0f, 0.6f, 0.8f), WorldAssets.Wood, null, false);
            }
            Mark(r, big ? TargetKind.Bunker : TargetKind.Bunker, big ? "БЛИНДАЖ" : "ДОТ", big ? 650f : 380f, big ? 500 : 300);
        }

        void BuildVehicles()
        {
            AddVehicle(new Vector3(55f, 0f, -150f), 32f, 0);
            AddVehicle(new Vector3(130f, 0f, -120f), 78f, 1);
            AddVehicle(new Vector3(-150f, 0f, 30f), 105f, 2);
            AddVehicle(new Vector3(210f, 0f, 40f), -28f, 0);
            AddVehicle(new Vector3(-35f, 0f, 185f), 118f, 3);
            AddVehicle(new Vector3(95f, 0f, 150f), 10f, 4);
            AddVehicle(new Vector3(265f, 0f, -200f), 55f, 0);
            AddVehicle(new Vector3(175f, 0f, 62f), -65f, 1);
            AddVehicle(new Vector3(-195f, 0f, -125f), 15f, 2);
            AddVehicle(new Vector3(-25f, 0f, 235f), 190f, 4);
        }

        void AddVehicle(Vector3 p, float yaw, int type)
        {
            vehicleSites.Add(new Vector2(p.x, p.z));
            p.y = Y(p.x, p.z);
            switch (type)
            {
                case 0: Tank(p, yaw); break;
                case 1: Bmp(p, yaw); break;
                case 2: Truck(p, yaw); break;
                case 3: FuelTruck(p, yaw); break;
                default: AaGun(p, yaw); break;
            }
        }

        void Tank(Vector3 p, float yaw)
        {
            var r = Root("Танк", p, yaw);
            U.BoxL(r.transform, "Гусеница-Л", new Vector3(-1.35f, 0.45f, 0f), new Vector3(0.7f, 0.9f, 5.6f), WorldAssets.DarkMetal, null, false);
            U.BoxL(r.transform, "Гусеница-П", new Vector3(1.35f, 0.45f, 0f), new Vector3(0.7f, 0.9f, 5.6f), WorldAssets.DarkMetal, null, false);
            for (int i = 0; i < 6; i++)
            {
                float z = -2.1f + i * 0.85f;
                U.CylL(r.transform, "Колесо", new Vector3(-1.42f, 0.55f, z), 1.0f, 0.22f, WorldAssets.DarkMetal, Quaternion.Euler(0f, 0f, 90f), false);
                U.CylL(r.transform, "Колесо", new Vector3(1.42f, 0.55f, z), 1.0f, 0.22f, WorldAssets.DarkMetal, Quaternion.Euler(0f, 0f, 90f), false);
            }
            U.BoxL(r.transform, "Корпус", new Vector3(0f, 1.02f, 0f), new Vector3(2.5f, 1.0f, 5.1f), WorldAssets.Camo, null, true);
            U.BoxL(r.transform, "Лоб", new Vector3(0f, 1.35f, 2.35f), new Vector3(2.5f, 0.5f, 1.1f), WorldAssets.Camo, Quaternion.Euler(34f, 0f, 0f), false);
            U.BoxL(r.transform, "Башня", new Vector3(0f, 1.9f, -0.15f), new Vector3(1.9f, 0.8f, 2.15f), WorldAssets.Camo, null, true);
            U.CylL(r.transform, "Люк", new Vector3(0f, 2.34f, -0.2f), 0.7f, 0.18f, WorldAssets.DarkMetal, null, false);
            U.CylL(r.transform, "Пушка", new Vector3(0f, 1.92f, 2.15f), 0.22f, 4.0f, WorldAssets.Metal, Quaternion.Euler(90f, 0f, 0f), false);
            U.BoxL(r.transform, "Дуло", new Vector3(0f, 1.92f, 4.15f), new Vector3(0.35f, 0.35f, 0.55f), WorldAssets.DarkMetal, null, false);
            U.BoxL(r.transform, "Антенна", new Vector3(0.85f, 2.7f, -1.0f), new Vector3(0.05f, 2.0f, 0.05f), WorldAssets.Dark, null, false);
            Mark(r, TargetKind.Vehicle, "ТАНК", 340f, 300);
        }

        void Bmp(Vector3 p, float yaw)
        {
            var r = Root("БМП", p, yaw);
            U.BoxL(r.transform, "Гусеница-Л", new Vector3(-1.25f, 0.38f, 0f), new Vector3(0.55f, 0.75f, 4.9f), WorldAssets.DarkMetal, null, false);
            U.BoxL(r.transform, "Гусеница-П", new Vector3(1.25f, 0.38f, 0f), new Vector3(0.55f, 0.75f, 4.9f), WorldAssets.DarkMetal, null, false);
            for (int i = 0; i < 5; i++)
            {
                float z = -1.85f + i * 0.92f;
                U.CylL(r.transform, "Колесо", new Vector3(-1.3f, 0.45f, z), 0.8f, 0.2f, WorldAssets.DarkMetal, Quaternion.Euler(0f, 0f, 90f), false);
                U.CylL(r.transform, "Колесо", new Vector3(1.3f, 0.45f, z), 0.8f, 0.2f, WorldAssets.DarkMetal, Quaternion.Euler(0f, 0f, 90f), false);
            }
            U.BoxL(r.transform, "Корпус", new Vector3(0f, 0.9f, 0f), new Vector3(2.25f, 1.0f, 4.6f), WorldAssets.Camo, null, true);
            U.BoxL(r.transform, "Лоб", new Vector3(0f, 1.15f, 2.1f), new Vector3(2.25f, 0.6f, 0.8f), WorldAssets.Camo, Quaternion.Euler(28f, 0f, 0f), false);
            U.BoxL(r.transform, "Башня", new Vector3(0f, 1.65f, 0.1f), new Vector3(1.45f, 0.6f, 1.8f), WorldAssets.Camo, null, true);
            U.CylL(r.transform, "Пушка", new Vector3(0f, 1.68f, 1.65f), 0.16f, 2.9f, WorldAssets.Metal, Quaternion.Euler(90f, 0f, 0f), false);
            U.BoxL(r.transform, "Антенна", new Vector3(-0.5f, 2.4f, -0.5f), new Vector3(0.04f, 1.7f, 0.04f), WorldAssets.Dark, null, false);
            Mark(r, TargetKind.Vehicle, "БМП", 250f, 250);
        }

        void Truck(Vector3 p, float yaw)
        {
            var r = Root("Грузовик", p, yaw);
            U.BoxL(r.transform, "Рама", new Vector3(0f, 0.55f, 0f), new Vector3(2.0f, 0.25f, 5.2f), WorldAssets.DarkMetal, null, false);
            U.BoxL(r.transform, "Кабина", new Vector3(0f, 1.25f, 1.65f), new Vector3(2.1f, 1.4f, 1.7f), WorldAssets.Camo, null, true);
            U.BoxL(r.transform, "Кузов", new Vector3(0f, 1.35f, -1.3f), new Vector3(2.2f, 1.7f, 3.0f), WorldAssets.Canvas, null, true);
            U.BoxL(r.transform, "Стекло", new Vector3(0f, 1.55f, 2.51f), new Vector3(1.7f, 0.55f, 0.06f), WorldAssets.Glass, null, false);
            for (int i = 0; i < 3; i++)
            {
                float z = -1.7f + i * 1.55f;
                U.CylL(r.transform, "Колесо", new Vector3(-1.0f, 0.45f, z), 0.9f, 0.28f, WorldAssets.Dark, Quaternion.Euler(0f, 0f, 90f), false);
                U.CylL(r.transform, "Колесо", new Vector3(1.0f, 0.45f, z), 0.9f, 0.28f, WorldAssets.Dark, Quaternion.Euler(0f, 0f, 90f), false);
            }
            Mark(r, TargetKind.Vehicle, "ГРУЗОВИК", 150f, 150);
        }

        void FuelTruck(Vector3 p, float yaw)
        {
            var r = Root("Топливовоз", p, yaw);
            U.BoxL(r.transform, "Рама", new Vector3(0f, 0.55f, 0f), new Vector3(2.0f, 0.25f, 5.4f), WorldAssets.DarkMetal, null, false);
            U.BoxL(r.transform, "Кабина", new Vector3(0f, 1.25f, 1.8f), new Vector3(2.1f, 1.4f, 1.6f), WorldAssets.Camo, null, true);
            U.CylL(r.transform, "Цистерна", new Vector3(0f, 1.8f, -1.2f), 2.0f, 4.0f, WorldAssets.Rust, Quaternion.Euler(90f, 0f, 0f), true);
            U.CylL(r.transform, "Люк", new Vector3(0f, 2.85f, -1.2f), 0.6f, 0.15f, WorldAssets.DarkMetal, null, false);
            U.BoxL(r.transform, "Стекло", new Vector3(0f, 1.55f, 2.58f), new Vector3(1.7f, 0.55f, 0.06f), WorldAssets.Glass, null, false);
            for (int i = 0; i < 3; i++)
            {
                float z = -1.8f + i * 1.65f;
                U.CylL(r.transform, "Колесо", new Vector3(-1.0f, 0.45f, z), 0.9f, 0.28f, WorldAssets.Dark, Quaternion.Euler(0f, 0f, 90f), false);
                U.CylL(r.transform, "Колесо", new Vector3(1.0f, 0.45f, z), 0.9f, 0.28f, WorldAssets.Dark, Quaternion.Euler(0f, 0f, 90f), false);
            }
            Mark(r, TargetKind.Depot, "ТОПЛИВОВОЗ", 190f, 220);
        }

        void AaGun(Vector3 p, float yaw)
        {
            var r = Root("ЗУ-23", p, yaw);
            U.BoxL(r.transform, "Станина", new Vector3(0f, 0.5f, 0f), new Vector3(2.3f, 0.6f, 2.6f), WorldAssets.DarkMetal, null, true);
            U.CylL(r.transform, "Тумба", new Vector3(0f, 1.0f, 0f), 0.9f, 0.7f, WorldAssets.Metal, null, false);
            U.BoxL(r.transform, "Люлька", new Vector3(0f, 1.25f, 0f), new Vector3(1.3f, 0.5f, 1.0f), WorldAssets.DarkMetal, null, false);
            U.CylL(r.transform, "Ствол-1", new Vector3(-0.25f, 1.5f, 1.2f), 0.13f, 2.6f, WorldAssets.Metal, Quaternion.Euler(72f, 0f, 0f), false);
            U.CylL(r.transform, "Ствол-2", new Vector3(0.25f, 1.5f, 1.2f), 0.13f, 2.6f, WorldAssets.Metal, Quaternion.Euler(72f, 0f, 0f), false);
            U.BoxL(r.transform, "Щит", new Vector3(0f, 1.35f, 1.05f), new Vector3(1.6f, 0.9f, 0.1f), WorldAssets.Metal, Quaternion.Euler(-15f, 0f, 0f), false);
            Mark(r, TargetKind.Vehicle, "ЗУ-23", 200f, 260);
        }

        void BuildDepot()
        {
            Vector3 p = new Vector3(140f, 0f, -170f);
            p.y = Y(p.x, p.z);
            var r = Root("Склад ГСМ", p, 18f);
            U.BoxL(r.transform, "Стена", new Vector3(0f, 0.8f, 0f), new Vector3(28f, 1.6f, 26f), WorldAssets.Concrete, null, false);
            U.BoxL(r.transform, "Стена-2", new Vector3(0f, 0.8f, 13f), new Vector3(28f, 1.6f, 0.4f), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Стена-3", new Vector3(0f, 0.8f, -13f), new Vector3(28f, 1.6f, 0.4f), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Стена-4", new Vector3(13f, 0.8f, 0f), new Vector3(0.4f, 1.6f, 26f), WorldAssets.Concrete, null, true);
            U.BoxL(r.transform, "Стена-5", new Vector3(-13f, 0.8f, 0f), new Vector3(0.4f, 1.6f, 26f), WorldAssets.Concrete, null, true);

            for (int i = 0; i < 3; i++)
            {
                Vector3 tp = p + new Vector3(-8f + i * 8f, 0f, 1f);
                tp.y = Y(tp.x, tp.z);
                var tr = Root("Резервуар", tp, 0f);
                U.CylL(tr.transform, "Цистерна", new Vector3(0f, 2.8f, 0f), 5.2f, 5.6f, WorldAssets.Rust, null, true);
                U.BoxL(tr.transform, "Обваловка", new Vector3(0f, 0.5f, 0f), new Vector3(7.6f, 1.0f, 7.6f), WorldAssets.Concrete, null, false);
                U.CylL(tr.transform, "Люк", new Vector3(0f, 5.7f, 0f), 0.8f, 0.2f, WorldAssets.DarkMetal, null, false);
                U.BoxL(tr.transform, "Лестница", new Vector3(2.7f, 2.8f, 0f), new Vector3(0.12f, 5.0f, 0.6f), WorldAssets.Metal, null, false);
                Mark(tr, TargetKind.Depot, "РЕЗЕРВУАР", 230f, 260);
            }
            Vector3 cp = p + new Vector3(-10f, 0f, 8f);
            cp.y = Y(cp.x, cp.z);
            var cr = Root("Склад боеприпасов", cp, 0f);
            for (int i = 0; i < 8; i++)
            {
                U.BoxL(cr.transform, "Ящик", new Vector3((i % 3) * 1.0f - 1f, 0.4f + (i / 3) * 0.8f, (i % 2) * 1.1f - 0.5f), new Vector3(0.9f, 0.75f, 0.8f), WorldAssets.Wood, null, i == 0);
            }
            Mark(cr, TargetKind.Depot, "БОЕПРИПАСЫ", 160f, 200);
        }

        void BuildRadarSite()
        {
            Vector3 p = new Vector3(-230f, 0f, -60f);
            p.y = Y(p.x, p.z);
            var r = Root("РЛС", p, 25f);
            U.BoxL(r.transform, "База", new Vector3(0f, 0.55f, 0f), new Vector3(4.0f, 0.7f, 3.0f), WorldAssets.DarkMetal, null, true);
            U.CylL(r.transform, "Мачта", new Vector3(0f, 2.2f, 0f), 0.35f, 4.0f, WorldAssets.Metal, null, false);
            U.SphereL(r.transform, "Антенна", new Vector3(0.0f, 4.4f, 0.5f), new Vector3(3.4f, 3.4f, 0.35f), WorldAssets.White, false);
            U.CylL(r.transform, "Штанга", new Vector3(0f, 4.4f, 0f), 0.12f, 1.2f, WorldAssets.Metal, Quaternion.Euler(90f, 0f, 0f), false);
            U.CylL(r.transform, "Генератор", new Vector3(2.1f, 0.5f, -1.2f), 0.8f, 0.8f, WorldAssets.Rust, Quaternion.identity, false);
            Mark(r, TargetKind.Radar, "РЛС", 230f, 350);
        }

        void BuildTrees()
        {
            var rng = new System.Random(4242);
            int made = 0;
            int guard = 0;
            while (made < 105 && guard++ < 1800)
            {
                float x = Mathf.Lerp(-275f, 330f, (float)rng.NextDouble());
                float z = Mathf.Lerp(-340f, 340f, (float)rng.NextDouble());
                if (x < -280f) continue;
                float h = Y(x, z);
                if (h < 1.2f || h > 30f) continue;
                if (Vector2.Distance(new Vector2(x, z), T.BaseCenter) < 30f) continue;
                if (Vector2.Distance(new Vector2(x, z), T.VillageCenter) < 12f) continue;
                if (T.TrenchMask(x, z) > 0.05f) continue;
                if (T.RoadMask(x, z) > 0.1f) continue;
                float s = Mathf.Max(
                    Mathf.Abs(Y(x + 3f, z) - Y(x - 3f, z)),
                    Mathf.Abs(Y(x, z + 3f) - Y(x, z - 3f)));
                if (s > 2.6f) continue;
                Tree(new Vector3(x, h, z), 0.8f + (float)rng.NextDouble() * 0.7f, rng);
                made++;
            }

            for (int i = 0; i < 90; i++)
            {
                float x = Mathf.Lerp(-270f, 330f, (float)rng.NextDouble());
                float z = Mathf.Lerp(-330f, 330f, (float)rng.NextDouble());
                if (x < -285f) continue;
                float h = Y(x, z);
                if (h < 1f) continue;
                if (Vector2.Distance(new Vector2(x, z), T.BaseCenter) < 22f) continue;
                U.Sphere(root, "Куст", new Vector3(x, h + 0.5f, z), Random.Range(1.0f, 2.2f), WorldAssets.Foliage, false);
            }
        }

        void Tree(Vector3 p, float scale, System.Random rng)
        {
            var r = Root("Дерево", p, (float)rng.NextDouble() * 360f);
            float trunkH = 3.2f * scale;
            U.CylL(r.transform, "Ствол", new Vector3(0f, trunkH * 0.5f, 0f), 0.34f * scale, trunkH, WorldAssets.Trunk, null, true);
            U.SphereL(r.transform, "Крона-1", new Vector3(0f, trunkH + 0.8f * scale, 0f), new Vector3(3.2f, 2.4f, 3.2f) * scale, WorldAssets.Foliage, false);
            U.SphereL(r.transform, "Крона-2", new Vector3(0.9f * scale, trunkH + 0.2f * scale, 0.3f * scale), new Vector3(2.2f, 1.8f, 2.2f) * scale, WorldAssets.Foliage, false);
            U.SphereL(r.transform, "Крона-3", new Vector3(-0.8f * scale, trunkH + 0.3f * scale, -0.2f * scale), new Vector3(2.0f, 1.6f, 2.0f) * scale, WorldAssets.Foliage, false);
        }

        void BuildPowerLine()
        {
            var road = T.Roads[0];
            Vector3 prevTop = Vector3.zero;
            bool hasPrev = false;
            for (int i = 0; i < road.Length - 1; i++)
            {
                Vector2 a = road[i];
                Vector2 b = road[i + 1];
                float len = Vector2.Distance(a, b);
                int count = Mathf.Max(1, Mathf.RoundToInt(len / 34f));
                for (int k = 0; k < count; k++)
                {
                    Vector2 p2 = Vector2.Lerp(a, b, (k + 0.5f) / count);
                    Vector3 p = new Vector3(p2.x, Y(p2.x, p2.y), p2.y);
                    U.Cyl(root, "Столб", p + Vector3.up * 4f, 0.26f, 8f, WorldAssets.Trunk, Quaternion.identity, true);
                    U.Box(root, "Траверса", p + Vector3.up * 7.4f, new Vector3(2.4f, 0.14f, 0.14f), WorldAssets.Trunk, Quaternion.identity, false);
                    Vector3 top = p + Vector3.up * 7.5f + new Vector3(0.9f, 0f, 0f);
                    if (hasPrev)
                    {
                        var wire = new GameObject("Провод");
                        wire.transform.SetParent(root, false);
                        var lr = wire.AddComponent<LineRenderer>();
                        lr.positionCount = 2;
                        lr.SetPosition(0, prevTop);
                        lr.SetPosition(1, top);
                        lr.startWidth = 0.045f;
                        lr.endWidth = 0.045f;
                        lr.sharedMaterial = WorldAssets.Wire;
                        lr.numCapVertices = 0;
                    }
                    prevTop = top;
                    hasPrev = true;
                }
            }
        }

        void BuildTurbines()
        {
            Turbine(new Vector3(-248f, 0f, 220f));
            Turbine(new Vector3(-290f, 0f, 150f));
            Turbine(new Vector3(-208f, 0f, 290f));
        }

        void Turbine(Vector3 p)
        {
            p.y = Y(p.x, p.z);
            var r = Root("Ветряк", p, 0f);
            U.CylL(r.transform, "Башня", new Vector3(0f, 15f, 0f), 2.2f, 30f, WorldAssets.White, null, true);
            U.BoxL(r.transform, "Гондола", new Vector3(0f, 30.2f, 0.8f), new Vector3(3.4f, 2.0f, 7.0f), WorldAssets.White, null, false);
            var pivot = new GameObject("Ротор").transform;
            pivot.SetParent(r.transform, false);
            pivot.localPosition = new Vector3(0f, 30.2f, 4.5f);
            for (int i = 0; i < 3; i++)
            {
                float a = i * 120f;
                var blade = new GameObject("Лопасть");
                blade.transform.SetParent(pivot, false);
                blade.transform.localRotation = Quaternion.Euler(0f, 0f, a);
                U.BoxL(blade.transform, "Лопасть", new Vector3(0f, 8.5f, 0f), new Vector3(1.3f, 17f, 0.35f), WorldAssets.White, null, false);
            }
            pivot.gameObject.AddComponent<Spin>().Setup(Vector3.forward, 22f);
        }

        void BuildClouds()
        {
            var rng = new System.Random(8989);
            for (int i = 0; i < 12; i++)
            {
                float x = Mathf.Lerp(-320f, 360f, (float)rng.NextDouble());
                float z = Mathf.Lerp(-340f, 340f, (float)rng.NextDouble());
                float y = 135f + (float)rng.NextDouble() * 90f;
                var c = new GameObject("Облако");
                c.transform.SetParent(root, false);
                c.transform.position = new Vector3(x, y, z);
                U.SphereL(c.transform, "Облако-1", new Vector3(0f, 0f, 0f), new Vector3(46f, 11f, 28f), WorldAssets.Cloud, false);
                U.SphereL(c.transform, "Облако-2", new Vector3(24f, 3f, 7f), new Vector3(32f, 9f, 24f), WorldAssets.Cloud, false);
                U.SphereL(c.transform, "Облако-3", new Vector3(-20f, -2f, -6f), new Vector3(38f, 8f, 22f), WorldAssets.Cloud, false);
                c.AddComponent<CloudDrift>().Setup(0.7f + (float)rng.NextDouble() * 0.7f);
            }
        }

        void BuildWrecks()
        {
            Vector3[] spots = {
                new Vector3(32f, 0f, -98f), new Vector3(-64f, 0f, 58f),
                new Vector3(158f, 0f, 62f), new Vector3(-172f, 0f, -132f),
                new Vector3(4f, 0f, 218f)
            };
            var rng = new System.Random(606);
            for (int i = 0; i < spots.Length; i++)
            {
                Vector3 p = spots[i];
                p.y = Y(p.x, p.z);
                var r = Root("Сгоревшая техника", p, (float)rng.NextDouble() * 360f);
                U.BoxL(r.transform, "Корпус", new Vector3(0f, 0.55f, 0f), new Vector3(2.2f, 0.9f, 4.2f), WorldAssets.Dark, Quaternion.Euler(2f, 0f, 6f), false);
                U.BoxL(r.transform, "Башня", new Vector3(0.2f, 1.25f, -0.3f), new Vector3(1.4f, 0.6f, 1.7f), WorldAssets.Rust, Quaternion.Euler(0f, 22f, 0f), false);
                U.BoxL(r.transform, "Обломок", new Vector3(-1.8f, 0.25f, 1.2f), new Vector3(1.4f, 0.4f, 2.1f), WorldAssets.Dark, Quaternion.Euler(0f, 40f, 8f), false);
                U.BoxL(r.transform, "Бревно", new Vector3(1.6f, 0.15f, -1.5f), new Vector3(0.2f, 0.2f, 3.0f), WorldAssets.Trunk, Quaternion.identity, false);
            }
        }

        public void SpawnReinforcement()
        {
            if (T == null || vehicleSites.Count == 0) return;
            Vector2 baseSite = vehicleSites[Random.Range(0, vehicleSites.Count)];
            Vector2 off = Random.insideUnitCircle * 18f;
            Vector2 site = baseSite + off;
            site.x = Mathf.Clamp(site.x, -275f, 340f);
            site.y = Mathf.Clamp(site.y, -345f, 345f);
            Vector3 p = new Vector3(site.x, 0f, site.y);
            p.y = Y(p.x, p.z);
            float yaw = Random.Range(0f, 360f);
            switch (Random.Range(0, 5))
            {
                case 0: Tank(p, yaw); break;
                case 1: Bmp(p, yaw); break;
                case 2: Truck(p, yaw); break;
                case 3: AaGun(p, yaw); break;
                default: FuelTruck(p, yaw); break;
            }
            barricadeCounter++;
        }
    }

    public class Spin : MonoBehaviour
    {
        Vector3 axis = Vector3.up;
        float speed = 100f;
        public void Setup(Vector3 a, float s)
        {
            axis = a.normalized;
            speed = s;
        }
        void Update()
        {
            transform.Rotate(axis * speed * Time.deltaTime, Space.Self);
        }
    }

    public class CloudDrift : MonoBehaviour
    {
        float speed = 1f;
        public void Setup(float s)
        {
            speed = s;
        }
        void Update()
        {
            var p = transform.position;
            p.x += speed * Time.deltaTime;
            if (p.x > 400f) p.x = -400f;
            transform.position = p;
        }
    }
}
