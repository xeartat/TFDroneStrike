using UnityEngine;

namespace TF
{
    public class HUD : MonoBehaviour
    {
        public static HUD I;

        GUIStyle big, mid, label, small, tiny, center, btn, feed;
        Font font;
        Font fontBold;
        bool styles;
        float sc = 1f;
        int styleH;
        bool showHelp;
        float hitUntil;
        float nextAimCheck;
        int aimMode;
        Texture2D vignette;
        Texture2D arrow;

        void Awake()
        {
            I = this;
            vignette = MakeVignette(256);
            arrow = MakeArrow(64);
        }

        void OnDestroy()
        {
            if (I == this) I = null;
        }

        public void HitMarker()
        {
            hitUntil = Time.unscaledTime + 0.16f;
        }

        void Update()
        {
            if (GameManager.I == null) return;
            if (GameManager.I.Started && Input.GetKeyDown(KeyCode.Escape))
                GameManager.I.TogglePause();
            if (Input.GetKeyDown(KeyCode.F1))
                showHelp = !showHelp;

            if (Time.unscaledTime > nextAimCheck)
            {
                nextAimCheck = Time.unscaledTime + 0.1f;
                aimMode = 0;
                var p = GameManager.I.Player;
                if (p != null && p.Cam != null && !p.Dead)
                {
                    RaycastHit hit;
                    if (Physics.Raycast(p.Cam.transform.position, p.Cam.transform.forward, out hit, 500f, Physics.DefaultRaycastLayers, QueryTriggerInteraction.Collide))
                    {
                        if (hit.collider != null)
                        {
                            if (hit.collider.GetComponentInParent<EnemyAircraft>() != null) aimMode = 2;
                            else if (hit.collider.GetComponentInParent<Target>() != null) aimMode = 1;
                        }
                    }
                }
            }
        }

        void OnGUI()
        {
            if (GameManager.I == null) return;
            GUI.depth = 5;
            EnsureStyles();
            if (!GameManager.I.Started)
            {
                DrawMenu();
                return;
            }

            DrawGame();
            DrawDamage();
            if (showHelp) DrawHelpOverlay();
            if (GameManager.I.Paused) DrawPause();
        }

        void EnsureStyles()
        {
            if (styles && styleH == Screen.height) return;
            styles = true;
            styleH = Screen.height;
            sc = Mathf.Clamp(Mathf.Min(Screen.width / 1600f, Screen.height / 900f), 0.65f, 1.4f);
            font = Resources.Load<Font>("Fonts/Roboto-Regular");
            fontBold = Resources.Load<Font>("Fonts/Roboto-Bold");
            if (font == null)
            {
                try
                {
                    font = Font.CreateDynamicFontFromOSFont(
                        new[] { "Roboto", "Noto Sans", "Droid Sans", "Arial", "Liberation Sans", "DejaVu Sans" },
                        Mathf.RoundToInt(24 * sc));
                }
                catch { font = null; }
            }
            if (font == null) font = GUI.skin.font;
            if (fontBold == null) fontBold = font;

            big = NewStyle(GUI.skin.label, 48, FontStyle.Bold, TextAnchor.MiddleCenter);
            mid = NewStyle(GUI.skin.label, 24, FontStyle.Bold, TextAnchor.MiddleCenter);
            label = NewStyle(GUI.skin.label, 20, FontStyle.Bold, TextAnchor.MiddleLeft);
            small = NewStyle(GUI.skin.label, 15, FontStyle.Normal, TextAnchor.MiddleLeft);
            tiny = NewStyle(GUI.skin.label, 12, FontStyle.Normal, TextAnchor.MiddleLeft);
            center = NewStyle(GUI.skin.label, 18, FontStyle.Bold, TextAnchor.MiddleCenter);
            feed = NewStyle(GUI.skin.label, 14, FontStyle.Bold, TextAnchor.MiddleRight);
            btn = NewStyle(GUI.skin.button, 21, FontStyle.Bold, TextAnchor.MiddleCenter);
            btn.normal.textColor = Color.white;
            btn.hover.textColor = Color.white;
            btn.active.textColor = Color.white;
        }

        GUIStyle NewStyle(GUIStyle baseStyle, int size, FontStyle fstyle, TextAnchor anchor)
        {
            var s = new GUIStyle(baseStyle);
            s.font = fstyle == FontStyle.Bold ? fontBold : font;
            s.fontSize = Mathf.RoundToInt(size * sc);
            s.fontStyle = fstyle;
            s.alignment = anchor;
            s.richText = false;
            s.normal.textColor = Color.white;
            return s;
        }

        void DrawText(Rect r, string text, GUIStyle st, Color c)
        {
            var old = st.normal.textColor;
            st.normal.textColor = c;
            GUI.Label(r, text, st);
            st.normal.textColor = old;
        }

        void Panel(Rect r, Color c)
        {
            GUI.color = c;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = Color.white;
        }

        void Bar(Rect r, float fill, Color bg, Color fg)
        {
            Panel(r, bg);
            Panel(new Rect(r.x, r.y, r.width * Mathf.Clamp01(fill), r.height), fg);
        }

        void DrawMenu()
        {
            float w = Screen.width, h = Screen.height;
            Panel(new Rect(0, 0, w, h), new Color(0.03f, 0.04f, 0.045f, 0.58f));
            Panel(new Rect(0, 0, w, 4f * sc), new Color(1f, 0.45f, 0.12f, 1f));

            float top = h * 0.10f;
            DrawText(new Rect(0, top, w, 70 * sc), "T-F DRONE STRIKE", big, Color.white);
            DrawText(new Rect(0, top + 70 * sc, w, 32 * sc), "КРЫМ · ДОНБАСС · FPV", mid, new Color(1f, 0.66f, 0.32f));
            DrawText(new Rect(0, top + 104 * sc, w, 26 * sc), "рекорд: " + GameManager.I.Best, small, new Color(0.75f, 0.8f, 0.85f));

            float cw = Mathf.Min(w * 0.56f, 640 * sc);
            float x = (w - cw) * 0.5f;
            float y = h * 0.36f;
            Panel(new Rect(x - 24 * sc, y - 20 * sc, cw + 48 * sc, 310 * sc), new Color(0f, 0f, 0f, 0.42f));

            GUI.backgroundColor = new Color(1f, 0.48f, 0.13f, 1f);
            if (GUI.Button(new Rect(x, y, cw, 58 * sc), "ВЗЛЁТ", btn))
            {
                GameManager.I.StartRun();
            }
            GUI.backgroundColor = new Color(0.22f, 0.25f, 0.27f, 1f);
            if (GUI.Button(new Rect(x, y + 72 * sc, cw, 48 * sc), showHelp ? "СКРЫТЬ УПРАВЛЕНИЕ" : "УПРАВЛЕНИЕ И ЦЕЛИ", btn))
            {
                showHelp = !showHelp;
            }
            if (GUI.Button(new Rect(x, y + 132 * sc, cw, 48 * sc), "ВЫХОД", btn))
            {
                GameManager.I.Quit();
            }
            GUI.backgroundColor = Color.white;

            if (showHelp)
            {
                float hy = y + 196 * sc;
                Panel(new Rect(x - 24 * sc, hy - 12 * sc, cw + 48 * sc, 330 * sc), new Color(0f, 0f, 0f, 0.42f));
                string txt;
                if (Application.isMobilePlatform)
                    txt = "ЛЕВЫЙ СТИК — тяга / рыскание\nПРАВЫЙ СТИК — тангаж / крен\nОГОНЬ — пулемёт\nБОМБА — сброс бомбы\nII — пауза\n\nБомби технику, окопы, блиндажи и склады.\nВлетай в цель на скорости — это таран.\nСбивай Шахеды, Герани, FPV-дроны и ракеты.\nСадись на базу для перевооружения.";
                else
                    txt = "W/S — тангаж, A/D — крен, Q/E — рыскание\nSHIFT / CTRL — тяга, SPACE — пулемёт\nB — сброс бомбы, C — камера, ESC — пауза\n\nБомби технику, окопы, блиндажи и склады.\nВлетай в цель на скорости — это таран.\nСбивай Шахеды, Герани, FPV-дроны и ракеты.\nСадись на базу для перевооружения.";
                DrawText(new Rect(x, hy, cw, 300 * sc), txt, small, new Color(0.88f, 0.9f, 0.9f));
            }

            DrawText(new Rect(0, h - 54 * sc, w, 24 * sc), "IL2CPP · ARM64 · БЕЗ АНТИ-ЧИТА · СБОРКА kindmops", tiny, new Color(0.65f, 0.7f, 0.72f));
            DrawText(new Rect(0, h - 30 * sc, w, 24 * sc), "T-F // made by kindmops on tg", tiny, new Color(0.5f, 0.55f, 0.58f));
        }

        void DrawGame()
        {
            var gm = GameManager.I;
            var p = gm.Player;
            float w = Screen.width, h = Screen.height;

            Panel(new Rect(w * 0.5f - 225 * sc, 12 * sc, 450 * sc, 66 * sc), new Color(0f, 0f, 0f, 0.38f));
            DrawText(new Rect(w * 0.5f - 225 * sc, 16 * sc, 450 * sc, 38 * sc), gm.Score.ToString(), mid, Color.white);
            DrawText(new Rect(w * 0.5f - 225 * sc, 50 * sc, 450 * sc, 22 * sc),
                "ВОЛНА " + gm.Wave + "   ·   ЦЕЛИ: " + Target.AliveCount + "   ·   СБИТО: " + gm.Kills,
                tiny, new Color(0.8f, 0.85f, 0.88f));

            Panel(new Rect(14 * sc, 68 * sc, 255 * sc, 96 * sc), new Color(0f, 0f, 0f, 0.36f));
            int mins = (int)(gm.RunTime / 60f);
            int secs = (int)(gm.RunTime % 60f);
            DrawText(new Rect(24 * sc, 72 * sc, 240 * sc, 24 * sc), "ВРЕМЯ " + mins.ToString("00") + ":" + secs.ToString("00"), small, Color.white);
            DrawText(new Rect(24 * sc, 96 * sc, 240 * sc, 22 * sc), "УНИЧТОЖЕНО: " + gm.Kills, tiny, new Color(0.9f, 0.9f, 0.9f));
            DrawText(new Rect(24 * sc, 118 * sc, 240 * sc, 22 * sc), "ПОТЕРЯНО ДРОНОВ: " + gm.Deaths, tiny, new Color(0.9f, 0.75f, 0.7f));
            DrawText(new Rect(24 * sc, 140 * sc, 240 * sc, 22 * sc), "РЕКОРД: " + gm.Best, tiny, new Color(0.75f, 0.8f, 0.85f));

            if (p != null && p.Dead)
            {
                DrawDeath(p, w, h);
            }
            else
            {
                DrawCrosshair(w, h);
                DrawTargetMarkers();
                DrawWarnings(w, h, p);
                DrawTelemetry(w, h, p);
            }

            DrawMinimap(w, h);
            DrawFeed(w, h);

            if (!Application.isMobilePlatform)
            {
                DrawText(new Rect(14 * sc, h - 28 * sc, w - 28 * sc, 20 * sc),
                    "WASD/QE · SHIFT/CTRL тяга · SPACE огонь · B бомба · C камера · ESC пауза · F1 помощь",
                    tiny, new Color(0.75f, 0.78f, 0.8f));
            }
        }

        void DrawCrosshair(float w, float h)
        {
            float cx = w * 0.5f, cy = h * 0.5f;
            Color c = aimMode == 2 ? new Color(1f, 0.25f, 0.2f) : (aimMode == 1 ? new Color(1f, 0.72f, 0.2f) : new Color(0.92f, 0.95f, 0.95f));
            float gap = 13 * sc, len = 9 * sc, th = 2f * sc;
            Panel(new Rect(cx - gap - len, cy - th * 0.5f, len, th), c);
            Panel(new Rect(cx + gap, cy - th * 0.5f, len, th), c);
            Panel(new Rect(cx - th * 0.5f, cy - gap - len, th, len), c);
            Panel(new Rect(cx - th * 0.5f, cy + gap, th, len), c);
            Panel(new Rect(cx - 2f * sc, cy - 2f * sc, 4f * sc, 4f * sc), c);

            if (Time.unscaledTime < hitUntil)
            {
                Color hm = new Color(1f, 0.9f, 0.5f);
                Panel(new Rect(cx - 12 * sc, cy - 12 * sc, 8 * sc, 2 * sc), hm);
                Panel(new Rect(cx + 4 * sc, cy - 12 * sc, 8 * sc, 2 * sc), hm);
                Panel(new Rect(cx - 12 * sc, cy + 10 * sc, 8 * sc, 2 * sc), hm);
                Panel(new Rect(cx + 4 * sc, cy + 10 * sc, 8 * sc, 2 * sc), hm);
            }
        }

        void DrawTargetMarkers()
        {
            var p = GameManager.I.Player;
            if (p == null || p.Cam == null) return;
            var cam = p.Cam;
            for (int i = 0; i < Target.All.Count; i++)
            {
                var t = Target.All[i];
                if (t == null || t.Destroyed || t.Kind == TargetKind.Infantry) continue;
                Vector3 wp = t.Center + Vector3.up * 1.5f;
                float dist = Vector3.Distance(p.transform.position, wp);
                if (dist > 700f) continue;
                Vector3 sp = cam.WorldToScreenPoint(wp);
                if (sp.z <= 0f) continue;
                float gx = sp.x;
                float gy = Screen.height - sp.y;
                if (gx < 20 || gx > Screen.width - 20 || gy < 60 || gy > Screen.height - 60) continue;
                Color c = TargetColor(t.Kind);
                Bracket(new Vector2(gx, gy), 14 * sc, c);
                if (dist < 380f)
                    DrawText(new Rect(gx - 70 * sc, gy + 17 * sc, 140 * sc, 18 * sc), t.Label + " " + (int)dist + "м", tiny, c);
            }

            for (int i = 0; i < EnemyAircraft.All.Count; i++)
            {
                var e = EnemyAircraft.All[i];
                if (e == null || e.Dead) continue;
                Vector3 sp = cam.WorldToScreenPoint(e.transform.position);
                if (sp.z <= 0f) continue;
                float gx = sp.x;
                float gy = Screen.height - sp.y;
                if (gx < 10 || gx > Screen.width - 10 || gy < 10 || gy > Screen.height - 10) continue;
                bool missile = e.Kind == EnemyKind.Missile;
                Color c = missile
                    ? Color.Lerp(new Color(1f, 0.35f, 0.1f), new Color(1f, 0.9f, 0.3f), Mathf.PingPong(Time.unscaledTime * 4f, 1f))
                    : new Color(1f, 0.22f, 0.18f);
                float d = Vector3.Distance(p.transform.position, e.transform.position);
                Bracket(new Vector2(gx, gy), 17 * sc, c);
                DrawText(new Rect(gx - 90 * sc, gy + 20 * sc, 180 * sc, 18 * sc), e.Label + " " + (int)d + "м", tiny, c);
            }
        }

        void Bracket(Vector2 p, float s, Color c)
        {
            float t = 2f * sc;
            Panel(new Rect(p.x - s, p.y - s, s * 0.55f, t), c);
            Panel(new Rect(p.x + s * 0.45f, p.y - s, s * 0.55f, t), c);
            Panel(new Rect(p.x - s, p.y - s, t, s * 0.55f), c);
            Panel(new Rect(p.x - s, p.y + s * 0.45f, t, s * 0.55f), c);
            Panel(new Rect(p.x + s - t, p.y - s, t, s * 0.55f), c);
            Panel(new Rect(p.x + s - t, p.y + s * 0.45f, t, s * 0.55f), c);
            Panel(new Rect(p.x - s, p.y + s - t, s * 0.55f, t), c);
            Panel(new Rect(p.x + s * 0.45f, p.y + s - t, s * 0.55f, t), c);
        }

        Color TargetColor(TargetKind k)
        {
            switch (k)
            {
                case TargetKind.Bunker: return new Color(1f, 0.45f, 0.18f);
                case TargetKind.Depot: return new Color(1f, 0.85f, 0.25f);
                case TargetKind.Radar: return new Color(0.45f, 0.9f, 1f);
                default: return new Color(1f, 0.7f, 0.25f);
            }
        }

        void DrawWarnings(float w, float h, DroneController p)
        {
            if (p == null) return;
            float cx = w * 0.5f;
            float y = h * 0.5f + 52 * sc;
            float now = Time.unscaledTime;

            EnemyAircraft nearest = null;
            float nd = 99999f;
            for (int i = 0; i < EnemyAircraft.All.Count; i++)
            {
                var e = EnemyAircraft.All[i];
                if (e == null || e.Dead) continue;
                float d = Vector3.Distance(p.transform.position, e.transform.position);
                if (d < nd) { nd = d; nearest = e; }
            }
            if (nearest != null && nd < 240f)
            {
                bool missile = nearest.Kind == EnemyKind.Missile;
                string text = (missile ? "РАКЕТА " : "УГРОЗА: " + nearest.Label + " ") + (int)nd + "м";
                Color c = missile
                    ? Color.Lerp(new Color(1f, 0.2f, 0.1f), new Color(1f, 0.9f, 0.4f), Mathf.PingPong(now * 4f, 1f))
                    : new Color(1f, 0.35f, 0.25f);
                DrawText(new Rect(cx - 260 * sc, y, 520 * sc, 26 * sc), text, center, c);
                y += 28 * sc;
            }

            if (p.Reloading)
            {
                DrawText(new Rect(cx - 220 * sc, y, 440 * sc, 24 * sc), "ПЕРЕЗАРЯДКА  " + p.ReloadTimer.ToString("0.0"), center, new Color(1f, 0.9f, 0.5f));
                y += 26 * sc;
            }
            if (p.NormalizedBattery < 0.2f)
            {
                DrawText(new Rect(cx - 220 * sc, y, 440 * sc, 24 * sc), "БАТАРЕЯ " + (int)(p.NormalizedBattery * 100f) + "%", center, new Color(1f, 0.65f, 0.2f));
                y += 26 * sc;
            }
            if (p.NormalizedHealth < 0.35f)
            {
                DrawText(new Rect(cx - 220 * sc, y, 440 * sc, 24 * sc), "КРИТИЧЕСКИЕ ПОВРЕЖДЕНИЯ", center, new Color(1f, 0.25f, 0.2f));
                y += 26 * sc;
            }
            if (p.BoundaryWarning)
            {
                DrawText(new Rect(cx - 220 * sc, y, 440 * sc, 24 * sc), "ВЫХОД ИЗ ЗОНЫ", center, new Color(1f, 0.55f, 0.2f));
            }
        }

        void DrawTelemetry(float w, float h, DroneController p)
        {
            if (p == null) return;
            float bw = Mathf.Min(w * 0.58f, 620 * sc);
            float bx = (w - bw) * 0.5f;
            float by = h - 94 * sc;
            Panel(new Rect(bx, by, bw, 78 * sc), new Color(0f, 0f, 0f, 0.44f));

            float labelW = 76 * sc;
            DrawText(new Rect(bx + 12 * sc, by + 6 * sc, labelW, 20 * sc), "КОРПУС", tiny, new Color(0.85f, 0.85f, 0.85f));
            Bar(new Rect(bx + labelW + 12 * sc, by + 10 * sc, 160 * sc, 10 * sc), p.NormalizedHealth,
                new Color(0.25f, 0.12f, 0.1f, 0.9f), p.NormalizedHealth > 0.35f ? new Color(0.4f, 0.9f, 0.45f) : new Color(1f, 0.3f, 0.2f));

            DrawText(new Rect(bx + 12 * sc, by + 28 * sc, labelW, 20 * sc), "ЗАРЯД", tiny, new Color(0.85f, 0.85f, 0.85f));
            Bar(new Rect(bx + labelW + 12 * sc, by + 32 * sc, 160 * sc, 10 * sc), p.NormalizedBattery,
                new Color(0.12f, 0.18f, 0.25f, 0.9f), p.NormalizedBattery > 0.2f ? new Color(0.35f, 0.75f, 1f) : new Color(1f, 0.6f, 0.2f));

            DrawText(new Rect(bx + 12 * sc, by + 50 * sc, bw - 24 * sc, 22 * sc),
                "БОМБ: " + p.Bombs + "     ПУЛЕМЁТ: " + p.Ammo, small, new Color(0.95f, 0.92f, 0.8f));

            DrawText(new Rect(bx + bw - 230 * sc, by + 6 * sc, 218 * sc, 22 * sc), "ALT  " + (int)p.Altitude + " м", small, Color.white);
            DrawText(new Rect(bx + bw - 230 * sc, by + 28 * sc, 218 * sc, 22 * sc), "SPD  " + (int)p.SpeedKmh + " км/ч", small, Color.white);
            DrawText(new Rect(bx + bw - 230 * sc, by + 50 * sc, 218 * sc, 22 * sc), p.ChaseCam ? "КАМЕРА: ПОГОНЯ" : "КАМЕРА: FPV", tiny, new Color(0.75f, 0.85f, 0.9f));
        }

        void DrawDeath(DroneController p, float w, float h)
        {
            Panel(new Rect(0, 0, w, h), new Color(0.12f, 0.01f, 0.01f, 0.30f));
            Panel(new Rect(w * 0.5f - 320 * sc, h * 0.5f - 105 * sc, 640 * sc, 210 * sc), new Color(0f, 0f, 0f, 0.55f));
            DrawText(new Rect(0, h * 0.5f - 85 * sc, w, 54 * sc), "ДРОН ПОТЕРЯН", big, new Color(1f, 0.35f, 0.25f));
            DrawText(new Rect(0, h * 0.5f - 18 * sc, w, 28 * sc), p.LastDeathReason, mid, new Color(1f, 0.8f, 0.6f));
            DrawText(new Rect(0, h * 0.5f + 18 * sc, w, 30 * sc), "РЕСПАВН ЧЕРЕЗ " + Mathf.Max(0f, p.RespawnTimer).ToString("0.0") + " c", center, Color.white);
            DrawText(new Rect(0, h * 0.5f + 52 * sc, w, 24 * sc), "СЧЁТ " + GameManager.I.Score + "  ·  СБИТО " + GameManager.I.Kills, small, new Color(0.85f, 0.85f, 0.85f));
        }

        void DrawMinimap(float w, float h)
        {
            float size = Mathf.Min(180 * sc, w * 0.18f);
            Rect outer = new Rect(w - size - 18 * sc, 18 * sc, size, size);
            Panel(new Rect(outer.x - 3 * sc, outer.y - 3 * sc, outer.width + 6 * sc, outer.height + 6 * sc), new Color(0f, 0f, 0f, 0.70f));
            Rect inner = new Rect(outer.x + 4 * sc, outer.y + 4 * sc, outer.width - 8 * sc, outer.height - 8 * sc);
            Panel(inner, new Color(0.16f, 0.23f, 0.14f, 0.94f));

            float seaW = Mathf.InverseLerp(-380f, 380f, -300f) * inner.width;
            Panel(new Rect(inner.x, inner.y, seaW, inner.height), new Color(0.12f, 0.32f, 0.44f, 0.95f));

            var t = TerrainBuilder.I;
            if (t != null)
            {
                Color road = new Color(0.55f, 0.44f, 0.28f, 0.9f);
                for (int r = 0; r < t.Roads.Count; r++)
                {
                    var roadPts = t.Roads[r];
                    for (int i = 0; i < roadPts.Length - 1; i++)
                    {
                        Vector2 a = WorldToMap(new Vector3(roadPts[i].x, 0f, roadPts[i].y), inner);
                        Vector2 b = WorldToMap(new Vector3(roadPts[i + 1].x, 0f, roadPts[i + 1].y), inner);
                        Line(a, b, road, 1.5f * sc);
                    }
                }
            }

            for (int i = 0; i < Target.All.Count; i++)
            {
                var tg = Target.All[i];
                if (tg == null || tg.Destroyed || tg.Kind == TargetKind.Infantry) continue;
                Vector2 m = WorldToMap(tg.transform.position, inner);
                Panel(new Rect(m.x - 2.5f * sc, m.y - 2.5f * sc, 5f * sc, 5f * sc), TargetColor(tg.Kind));
            }

            for (int i = 0; i < EnemyAircraft.All.Count; i++)
            {
                var e = EnemyAircraft.All[i];
                if (e == null || e.Dead) continue;
                Vector2 m = WorldToMap(e.transform.position, inner);
                Color c = e.Kind == EnemyKind.Missile ? new Color(1f, 0.4f, 0.1f) : new Color(1f, 0.2f, 0.15f);
                Panel(new Rect(m.x - 3f * sc, m.y - 3f * sc, 6f * sc, 6f * sc), c);
            }

            if (GameManager.I.Player != null)
            {
                Vector2 pm = WorldToMap(GameManager.I.Player.transform.position, inner);
                Panel(new Rect(pm.x - 3f * sc, pm.y - 3f * sc, 6f * sc, 6f * sc), new Color(0.3f, 0.9f, 1f));
                var saved = GUI.matrix;
                float yaw = GameManager.I.Player.transform.eulerAngles.y;
                GUIUtility.RotateAroundPivot(yaw, pm);
                GUI.color = Color.white;
                GUI.DrawTexture(new Rect(pm.x - 6 * sc, pm.y - 9 * sc, 12 * sc, 18 * sc), arrow);
                GUI.matrix = saved;
                GUI.color = Color.white;
            }

            Vector2 baseM = WorldToMap(GameManager.I.SpawnPoint, inner);
            Panel(new Rect(baseM.x - 4f * sc, baseM.y - 4f * sc, 8f * sc, 8f * sc), new Color(0.35f, 1f, 0.7f));
            DrawText(new Rect(inner.x + 5 * sc, inner.y + 3 * sc, 100 * sc, 16 * sc), "КАРТА", tiny, new Color(0.9f, 0.95f, 0.9f));
        }

        void DrawFeed(float w, float h)
        {
            var events = GameManager.I.Events;
            if (events == null) return;
            float right = w - 22 * sc;
            float y = 18 * sc + Mathf.Min(180 * sc, w * 0.18f) + 18 * sc;
            int start = Mathf.Max(0, events.Count - 6);
            for (int i = start; i < events.Count; i++)
            {
                var e = events[i];
                float age = Time.unscaledTime - e.Time;
                if (age > 8f) continue;
                float a = age > 6f ? Mathf.Clamp01(1f - (age - 6f) / 2f) : 1f;
                var c = e.Color;
                c.a = a;
                DrawText(new Rect(w * 0.45f, y, right - w * 0.45f, 20 * sc), e.Text, feed, c);
                y += 21 * sc;
            }
        }

        void DrawDamage()
        {
            var p = GameManager.I.Player;
            if (p == null) return;
            float low = 1f - p.NormalizedHealth;
            float dmg = Mathf.Clamp01(p.DamageFlash * 0.55f + low * low * 0.28f);
            if (dmg > 0.02f)
            {
                GUI.color = new Color(1f, 0.08f, 0.04f, dmg);
                GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), vignette);
                GUI.color = Color.white;
            }
            GUI.color = new Color(0f, 0f, 0f, 0.25f);
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height), vignette);
            GUI.color = Color.white;
        }

        void DrawHelpOverlay()
        {
            float w = Screen.width, h = Screen.height;
            Panel(new Rect(0, 0, w, h), new Color(0f, 0f, 0f, 0.68f));
            float cw = Mathf.Min(w * 0.7f, 760 * sc);
            float x = (w - cw) * 0.5f;
            float y = h * 0.16f;
            Panel(new Rect(x - 20 * sc, y - 16 * sc, cw + 40 * sc, 430 * sc), new Color(0.04f, 0.05f, 0.05f, 0.92f));
            DrawText(new Rect(x, y, cw, 36 * sc), "УПРАВЛЕНИЕ", mid, new Color(1f, 0.65f, 0.3f));
            string txt;
            if (Application.isMobilePlatform)
                txt = "ЛЕВЫЙ СТИК — тяга и рыскание\nПРАВЫЙ СТИК — тангаж и крен\n\nОГОНЬ — пулемёт (держать)\nБОМБА — сброс бомбы\nII — пауза\n\nБомби технику, окопы, блиндажи и склады.\nВлетай в цель на скорости — это таран.\nСбивай Шахеды, Герани, FPV-дроны и ракеты.\nСадись на базу для перевооружения.\n\nF1 — закрыть помощь";
            else
                txt = "W/S — тангаж\nA/D — крен\nQ/E — рыскание\nSHIFT / CTRL — тяга\nSPACE — пулемёт\nB — сброс бомбы\nC — FPV / камера погони\nESC — пауза\n\nБомби технику, окопы, блиндажи и склады.\nВлетай в цель на скорости — это таран.\nСбивай Шахеды, Герани, FPV-дроны и ракеты.\nСадись на базу для перевооружения.\n\nF1 — закрыть помощь";
            DrawText(new Rect(x, y + 48 * sc, cw, 360 * sc), txt, small, new Color(0.9f, 0.92f, 0.92f));
        }

        void DrawPause()
        {
            float w = Screen.width, h = Screen.height;
            Panel(new Rect(0, 0, w, h), new Color(0f, 0f, 0f, 0.72f));
            float cw = Mathf.Min(w * 0.5f, 520 * sc);
            float x = (w - cw) * 0.5f;
            float y = h * 0.24f;
            Panel(new Rect(x - 22 * sc, y - 18 * sc, cw + 44 * sc, 330 * sc), new Color(0.04f, 0.05f, 0.05f, 0.94f));
            DrawText(new Rect(x, y, cw, 50 * sc), "ПАУЗА", big, Color.white);
            DrawText(new Rect(x, y + 54 * sc, cw, 24 * sc), "СЧЁТ " + GameManager.I.Score + " · РЕКОРД " + GameManager.I.Best, small, new Color(0.8f, 0.85f, 0.85f));

            GUI.backgroundColor = new Color(1f, 0.48f, 0.13f, 1f);
            if (GUI.Button(new Rect(x, y + 96 * sc, cw, 52 * sc), "ПРОДОЛЖИТЬ", btn)) GameManager.I.TogglePause();
            GUI.backgroundColor = new Color(0.25f, 0.28f, 0.3f, 1f);
            if (GUI.Button(new Rect(x, y + 158 * sc, cw, 46 * sc), "ЗАНОВО", btn)) GameManager.I.Restart();
            if (GUI.Button(new Rect(x, y + 214 * sc, cw, 46 * sc), "ВЫХОД", btn)) GameManager.I.Quit();
            GUI.backgroundColor = Color.white;
            DrawText(new Rect(x, y + 274 * sc, cw, 24 * sc), "F1 — помощь по управлению", tiny, new Color(0.7f, 0.75f, 0.78f));
        }

        Vector2 WorldToMap(Vector3 p, Rect r)
        {
            float u = Mathf.InverseLerp(-380f, 380f, p.x);
            float v = Mathf.InverseLerp(-380f, 380f, p.z);
            return new Vector2(r.x + u * r.width, r.yMax - v * r.height);
        }

        void Line(Vector2 a, Vector2 b, Color c, float width)
        {
            Vector2 d = b - a;
            float len = d.magnitude;
            if (len < 0.01f) return;
            float angle = Mathf.Atan2(d.y, d.x) * Mathf.Rad2Deg;
            var saved = GUI.matrix;
            GUIUtility.RotateAroundPivot(angle, a);
            Panel(new Rect(a.x, a.y - width * 0.5f, len, width), c);
            GUI.matrix = saved;
        }

        Texture2D MakeVignette(int size)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            var px = new Color32[size * size];
            float half = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float dx = (x - half) / half;
                    float dy = (y - half) / half;
                    float d = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.SmoothStep(0.30f, 1.1f, d);
                    px[y * size + x] = new Color(1f, 1f, 1f, a);
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }

        Texture2D MakeArrow(int size)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            var px = new Color32[size * size];
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float nx = (x - size * 0.5f) / (size * 0.5f);
                    float ny = (y - size * 0.5f) / (size * 0.5f);
                    bool inside = ny > -0.85f && ny < 0.9f && Mathf.Abs(nx) < (0.55f - ny * 0.30f);
                    px[y * size + x] = inside ? new Color(1f, 1f, 1f, 1f) : new Color(1f, 1f, 1f, 0f);
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }
    }
}
