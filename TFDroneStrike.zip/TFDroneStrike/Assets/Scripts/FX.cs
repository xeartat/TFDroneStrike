using UnityEngine;

namespace TF
{
    public static class FX
    {
        static Transform root;
        static bool ready;

        public static void Init(Transform parent)
        {
            if (ready && root != null) return;
            var go = new GameObject("FX");
            go.transform.SetParent(parent, false);
            root = go.transform;
            ready = true;
        }

        public static void Explosion(Vector3 pos, float scale = 1f)
        {
            if (!ready) return;

            var fire = MakePS("Огонь", pos, WorldAssets.FireMat, 26, 0.30f, 0.75f, 2.5f, 8.5f, 1.2f, 3.2f,
                new Color(1f, 0.62f, 0.15f, 1f), 0.35f, 0.9f);
            fire.Emit(Mathf.RoundToInt(22 * scale));
            DestroyPS(fire.gameObject, 2.2f);

            var smoke = MakePS("Дым", pos, WorldAssets.SmokeMat, 18, 1.4f, 3.4f, 1f, 4.2f, 2.5f, 6f,
                new Color(0.20f, 0.19f, 0.17f, 0.92f), -0.04f, 1.4f);
            smoke.Emit(Mathf.RoundToInt(16 * scale));
            DestroyPS(smoke.gameObject, 4.5f);

            var sparks = MakePS("Искры", pos, WorldAssets.SparkMat, 22, 0.25f, 0.75f, 6f, 17f, 0.08f, 0.26f,
                new Color(1f, 0.90f, 0.35f, 1f), 1.35f, 0.35f);
            sparks.Emit(Mathf.RoundToInt(24 * scale));
            DestroyPS(sparks.gameObject, 1.5f);

            var lightGo = new GameObject("Вспышка");
            lightGo.transform.SetParent(root, false);
            lightGo.transform.position = pos + Vector3.up * 0.5f;
            var light = lightGo.AddComponent<Light>();
            light.type = LightType.Point;
            light.color = new Color(1f, 0.65f, 0.25f);
            light.range = 24f * scale;
            light.intensity = 7f * scale;
            light.shadows = LightShadows.None;
            lightGo.AddComponent<FlashFade>().Setup(0.26f, 7f * scale);
            Object.Destroy(lightGo, 0.35f);

            Ring(pos, scale);
            AudioSynth.Play(AudioSynth.Boom, pos, Mathf.Clamp01(0.55f * scale + 0.25f), Random.Range(0.82f, 1.08f), 900f);

            if (GameManager.I != null && GameManager.I.Player != null)
            {
                float d = Vector3.Distance(GameManager.I.Player.transform.position, pos);
                GameManager.I.Player.AddShake(Mathf.Clamp01(scale * 2.8f / (1f + d * 0.07f)));
            }
        }

        public static void Impact(Vector3 pos, Vector3 normal, bool metal)
        {
            if (!ready) return;
            var sparks = MakePS("Попадание", pos + normal * 0.05f, WorldAssets.SparkMat, 12, 0.15f, 0.4f, 2f, 8f, 0.05f, 0.16f,
                metal ? new Color(1f, 0.95f, 0.55f, 1f) : new Color(0.75f, 0.62f, 0.42f, 1f), 1.2f, 0.15f);
            sparks.Emit(metal ? 7 : 4);
            DestroyPS(sparks.gameObject, 0.9f);
        }

        public static void Tracer(Vector3 a, Vector3 b)
        {
            if (!ready) return;
            var go = new GameObject("Трассер");
            go.transform.SetParent(root, false);
            var lr = go.AddComponent<LineRenderer>();
            lr.positionCount = 2;
            lr.useWorldSpace = true;
            lr.SetPosition(0, a);
            lr.SetPosition(1, b);
            lr.startWidth = 0.075f;
            lr.endWidth = 0.018f;
            lr.numCapVertices = 2;
            lr.sharedMaterial = WorldAssets.TracerMat;
            lr.startColor = new Color(1f, 0.82f, 0.32f, 1f);
            lr.endColor = new Color(1f, 0.45f, 0.08f, 0f);
            Object.Destroy(go, 0.11f);
        }

        public static void Muzzle(Vector3 pos)
        {
            if (!ready) return;
            var sparks = MakePS("Дуло", pos, WorldAssets.SparkMat, 6, 0.06f, 0.15f, 1f, 3f, 0.06f, 0.16f,
                new Color(1f, 0.8f, 0.3f, 1f), 0f, 0.05f);
            sparks.Emit(3);
            DestroyPS(sparks.gameObject, 0.4f);
        }

        public static void WreckSmoke(Transform anchor, float duration)
        {
            if (!ready || anchor == null) return;
            var go = new GameObject("Дым-обломки");
            go.transform.SetParent(root, false);
            go.transform.position = anchor.position + Vector3.up * 1.5f;
            var ps = go.AddComponent<ParticleSystem>();
            var main = ps.main;
            main.loop = true;
            main.playOnAwake = false;
            main.duration = duration;
            main.startLifetime = new ParticleSystem.MinMaxCurve(2.2f, 4.2f);
            main.startSpeed = new ParticleSystem.MinMaxCurve(0.6f, 1.8f);
            main.startSize = new ParticleSystem.MinMaxCurve(1.8f, 4.0f);
            main.startColor = new Color(0.14f, 0.13f, 0.12f, 0.55f);
            main.maxParticles = 50;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.gravityModifier = -0.04f;
            var em = ps.emission;
            em.enabled = true;
            em.rateOverTime = 3.5f;
            var shape = ps.shape;
            shape.enabled = true;
            shape.shapeType = ParticleSystemShapeType.Cone;
            shape.angle = 8f;
            shape.radius = 0.6f;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = WorldAssets.SmokeMat;
            r.renderMode = ParticleSystemRenderMode.Billboard;
            var col = ps.colorOverLifetime;
            col.enabled = true;
            var g = new Gradient();
            g.SetKeys(
                new[] { new GradientColorKey(new Color(0.16f, 0.15f, 0.14f), 0f), new GradientColorKey(new Color(0.30f, 0.29f, 0.27f), 1f) },
                new[] { new GradientAlphaKey(0.55f, 0f), new GradientAlphaKey(0.35f, 0.4f), new GradientAlphaKey(0f, 1f) });
            col.color = new ParticleSystem.MinMaxGradient(g);
            var sol = ps.sizeOverLifetime;
            sol.enabled = true;
            sol.size = new ParticleSystem.MinMaxCurve(1f, AnimationCurve.Linear(0f, 0.45f, 1f, 1.5f));
            ps.Play();
            Object.Destroy(go, duration);
        }

        public static TrailRenderer Trail(GameObject go, Color color, float width, float time)
        {
            if (!ready || go == null) return null;
            var tr = go.AddComponent<TrailRenderer>();
            tr.time = time;
            tr.minVertexDistance = 0.7f;
            tr.startWidth = width;
            tr.endWidth = 0f;
            tr.sharedMaterial = WorldAssets.SmokeMat;
            tr.startColor = color;
            tr.endColor = new Color(color.r, color.g, color.b, 0f);
            tr.numCapVertices = 0;
            tr.autodestruct = false;
            return tr;
        }

        static ParticleSystem MakePS(string name, Vector3 pos, Material mat, int max, float lifeMin, float lifeMax,
            float speedMin, float speedMax, float sizeMin, float sizeMax, Color color, float gravity, float radius)
        {
            var go = new GameObject(name);
            go.transform.SetParent(root, false);
            go.transform.position = pos;
            var ps = go.AddComponent<ParticleSystem>();
            var main = ps.main;
            main.loop = false;
            main.playOnAwake = false;
            main.duration = lifeMax + 0.2f;
            main.startLifetime = new ParticleSystem.MinMaxCurve(lifeMin, lifeMax);
            main.startSpeed = new ParticleSystem.MinMaxCurve(speedMin, speedMax);
            main.startSize = new ParticleSystem.MinMaxCurve(sizeMin, sizeMax);
            main.startColor = color;
            main.maxParticles = max;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            main.gravityModifier = gravity;
            main.startRotation = new ParticleSystem.MinMaxCurve(0f, Mathf.PI * 2f);
            var em = ps.emission;
            em.enabled = false;
            var shape = ps.shape;
            shape.enabled = true;
            shape.shapeType = ParticleSystemShapeType.Sphere;
            shape.radius = radius;
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = mat;
            r.renderMode = ParticleSystemRenderMode.Billboard;
            var col = ps.colorOverLifetime;
            col.enabled = true;
            var g = new Gradient();
            g.SetKeys(
                new[] { new GradientColorKey(color, 0f), new GradientColorKey(color * 0.6f, 1f) },
                new[] { new GradientAlphaKey(1f, 0f), new GradientAlphaKey(0.75f, 0.35f), new GradientAlphaKey(0f, 1f) });
            col.color = new ParticleSystem.MinMaxGradient(g);
            var sol = ps.sizeOverLifetime;
            sol.enabled = true;
            sol.size = new ParticleSystem.MinMaxCurve(1f, AnimationCurve.Linear(0f, 1f, 1f, 0.15f));
            ps.Play();
            return ps;
        }

        static void DestroyPS(GameObject go, float delay)
        {
            Object.Destroy(go, delay);
        }

        static void Ring(Vector3 pos, float scale)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Quad);
            go.name = "Ударная волна";
            Object.Destroy(go.GetComponent<Collider>());
            go.transform.SetParent(root, false);
            go.transform.position = pos + Vector3.up * 0.25f;
            go.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            go.transform.localScale = Vector3.one;
            var mat = new Material(WorldAssets.RingMat);
            mat.color = new Color(1f, 0.65f, 0.25f, 0.75f);
            var r = go.GetComponent<Renderer>();
            r.sharedMaterial = mat;
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            r.receiveShadows = false;
            var fx = go.AddComponent<ShockRing>();
            fx.Setup(mat, 0.5f, 8f * scale);
        }
    }

    public class FlashFade : MonoBehaviour
    {
        float life;
        float intensity;
        float t;
        Light l;

        public void Setup(float duration, float startIntensity)
        {
            life = duration;
            intensity = startIntensity;
        }

        void Awake()
        {
            l = GetComponent<Light>();
        }

        void Update()
        {
            if (l == null) return;
            t += Time.deltaTime;
            float k = Mathf.Clamp01(1f - t / Mathf.Max(0.01f, life));
            l.intensity = intensity * k;
        }
    }

    public class ShockRing : MonoBehaviour
    {
        Material mat;
        float life;
        float maxScale;
        float t;

        public void Setup(Material m, float duration, float scale)
        {
            mat = m;
            life = duration;
            maxScale = scale;
        }

        void Update()
        {
            t += Time.deltaTime;
            float k = Mathf.Clamp01(t / Mathf.Max(0.01f, life));
            transform.localScale = Vector3.one * Mathf.Lerp(1f, maxScale, k);
            if (mat != null)
            {
                var c = mat.color;
                c.a = Mathf.Lerp(0.75f, 0f, k);
                mat.color = c;
            }
            if (t >= life) Object.Destroy(gameObject);
        }
    }
}
