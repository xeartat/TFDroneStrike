using UnityEngine;

namespace TF
{
    public static class WorldAssets
    {
        public static bool Ready;

        public static Texture2D GrassTex, DirtTex, RockTex, SandTex, ConcreteTex, MetalTex, RustTex, WoodTex, CamoTex, WaterTex;
        public static Texture2D SoftTex, RingTex;
        public static Texture2D WhiteTex { get { return Texture2D.whiteTexture; } }

        public static Material TerrainMat, SkyMat;
        public static Material Grass, Dirt, Sand, Rock, Concrete, House, Metal, DarkMetal, Rust, Wood, Roof, Camo, Canvas;
        public static Material Sandbag, Foliage, Trunk, Water, Cloud, Dark, Glass, White, Wire;
        public static Material LedRed, LedGreen, TracerMat, FireMat, SmokeMat, SparkMat, RingMat;

        public static void Init()
        {
            if (Ready) return;
            Ready = true;

            GrassTex = LoadTex("Textures/grass", new Color(0.31f, 0.40f, 0.17f));
            DirtTex = LoadTex("Textures/dirt", new Color(0.42f, 0.34f, 0.24f));
            RockTex = LoadTex("Textures/rock", new Color(0.43f, 0.43f, 0.41f));
            SandTex = LoadTex("Textures/sand", new Color(0.65f, 0.58f, 0.42f));
            ConcreteTex = LoadTex("Textures/concrete", new Color(0.58f, 0.58f, 0.56f));
            MetalTex = LoadTex("Textures/metal", new Color(0.48f, 0.50f, 0.52f));
            RustTex = LoadTex("Textures/rust", new Color(0.41f, 0.27f, 0.18f));
            WoodTex = LoadTex("Textures/wood", new Color(0.35f, 0.25f, 0.16f));
            CamoTex = LoadTex("Textures/camo", new Color(0.31f, 0.34f, 0.20f));
            WaterTex = LoadTex("Textures/water", new Color(0.09f, 0.24f, 0.32f));

            SoftTex = SoftCircle(64, 0.05f);
            RingTex = Ring(128, 0.72f, 0.90f);

            Grass = Std(GrassTex, Color.white, 0.05f, 0f, 3f);
            Dirt = Std(DirtTex, Color.white, 0.05f, 0f, 2f);
            Sand = Std(SandTex, Color.white, 0.08f, 0f, 3f);
            Rock = Std(RockTex, new Color(0.82f, 0.82f, 0.80f), 0.12f, 0f, 2f);
            Concrete = Std(ConcreteTex, new Color(0.82f, 0.82f, 0.80f), 0.18f, 0f, 3f);
            House = Std(ConcreteTex, new Color(0.93f, 0.89f, 0.78f), 0.15f, 0f, 3f);
            Metal = Std(MetalTex, new Color(0.62f, 0.66f, 0.62f), 0.45f, 0.35f, 2f);
            DarkMetal = Std(MetalTex, new Color(0.20f, 0.22f, 0.20f), 0.42f, 0.30f, 2f);
            Rust = Std(RustTex, new Color(0.75f, 0.62f, 0.50f), 0.24f, 0.10f, 2f);
            Wood = Std(WoodTex, new Color(0.80f, 0.66f, 0.48f), 0.10f, 0f, 2f);
            Roof = Std(RustTex, new Color(0.62f, 0.50f, 0.45f), 0.16f, 0.05f, 3f);
            Camo = Std(CamoTex, new Color(0.90f, 0.92f, 0.82f), 0.30f, 0.05f, 2f);
            Canvas = Std(CamoTex, new Color(0.82f, 0.86f, 0.70f), 0.10f, 0f, 3f);
            Sandbag = Std(SandTex, new Color(0.73f, 0.67f, 0.49f), 0.06f, 0f, 3f);
            Foliage = Std(Noise(new Color(0.19f, 0.31f, 0.11f), new Color(0.36f, 0.47f, 0.18f), 128, 16f), Color.white, 0.05f, 0f, 2f);
            Trunk = Std(WoodTex, new Color(0.62f, 0.47f, 0.31f), 0.08f, 0f, 2f);
            Water = Std(WaterTex, new Color(0.62f, 0.82f, 0.92f), 0.93f, 0.12f, 22f);
            Cloud = Std(Noise(new Color(0.88f, 0.90f, 0.92f), new Color(1f, 1f, 1f), 128, 5f), Color.white, 0.02f, 0f, 1f);
            Dark = Std(null, new Color(0.10f, 0.10f, 0.09f), 0.20f, 0f, 1f);
            Glass = Std(MetalTex, new Color(0.10f, 0.20f, 0.24f), 0.92f, 0.55f, 2f);
            White = Std(null, new Color(0.94f, 0.94f, 0.92f), 0.20f, 0f, 1f);
            Wire = Std(null, new Color(0.07f, 0.07f, 0.07f), 0.15f, 0.30f, 1f);

            LedRed = Led(new Color(1f, 0.08f, 0.04f));
            LedGreen = Led(new Color(0.15f, 1f, 0.25f));

            TracerMat = FxMat("TF/ParticleAdditive", "Shaders/TFParticleAdditive", SoftTex);
            FireMat = FxMat("TF/ParticleAdditive", "Shaders/TFParticleAdditive", SoftTex);
            SmokeMat = FxMat("TF/ParticleAlpha", "Shaders/TFParticleAlpha", SoftTex);
            SparkMat = FxMat("TF/ParticleAdditive", "Shaders/TFParticleAdditive", SoftTex);
            RingMat = FxMat("TF/ParticleAdditive", "Shaders/TFParticleAdditive", RingTex);

            var terrainShader = FindShader("TF/Terrain", "Shaders/TFTerrain");
            if (terrainShader != null)
            {
                TerrainMat = new Material(terrainShader);
                TerrainMat.SetTexture("_GrassTex", GrassTex);
                TerrainMat.SetTexture("_DirtTex", DirtTex);
                TerrainMat.SetTexture("_RockTex", RockTex);
                TerrainMat.SetTexture("_SandTex", SandTex);
                TerrainMat.SetFloat("_Brightness", 1.05f);
            }
            else
            {
                TerrainMat = Std(GrassTex, new Color(0.86f, 0.86f, 0.78f), 0.06f, 0f, 1f);
            }

            var skyShader = FindShader("TF/Sky", "Shaders/TFSky");
            if (skyShader != null)
            {
                SkyMat = new Material(skyShader);
                SkyMat.SetColor("_TopColor", new Color(0.13f, 0.30f, 0.58f, 1f));
                SkyMat.SetColor("_HorizonColor", new Color(0.73f, 0.79f, 0.84f, 1f));
                SkyMat.SetColor("_GroundColor", new Color(0.34f, 0.32f, 0.27f, 1f));
                SkyMat.SetColor("_SunColor", new Color(1f, 0.86f, 0.62f, 1f));
                SkyMat.SetFloat("_SunSize", 0.022f);
            }
        }

        public static Material Std(Texture2D tex, Color tint, float smoothness, float metallic, float tiling)
        {
            var template = Resources.Load<Material>("TFStandard");
            var sh = template != null ? template.shader : Shader.Find("Standard");
            if (sh == null) sh = Shader.Find("Diffuse");
            if (sh == null) sh = Shader.Find("Sprites/Default");
            if (sh == null)
            {
                Debug.LogError("[T-F] Нет доступного шейдера для материалов. Запусти T-F/1. Setup Project.");
                return null;
            }
            var m = new Material(sh);
            m.color = tint;
            if (tex != null)
            {
                m.mainTexture = tex;
                m.mainTextureScale = new Vector2(tiling, tiling);
            }
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smoothness);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metallic);
            m.enableInstancing = true;
            return m;
        }

        public static Material Led(Color c)
        {
            var m = Std(null, c, 0.4f, 0f, 1f);
            m.EnableKeyword("_EMISSION");
            m.SetColor("_EmissionColor", c * 2.5f);
            return m;
        }

        static Material FxMat(string shaderName, string resourcePath, Texture2D tex)
        {
            var sh = FindShader(shaderName, resourcePath);
            if (sh == null) sh = Shader.Find("Sprites/Default");
            var m = new Material(sh);
            m.mainTexture = tex;
            m.color = Color.white;
            return m;
        }

        static Shader FindShader(string name, string resourcePath)
        {
            var sh = Shader.Find(name);
            if (sh != null) return sh;
            return Resources.Load<Shader>(resourcePath);
        }

        static Texture2D LoadTex(string path, Color fallback)
        {
            var t = Resources.Load<Texture2D>(path);
            if (t != null)
            {
                t.wrapMode = TextureWrapMode.Repeat;
                t.anisoLevel = 4;
                return t;
            }
            return Noise(fallback * 0.78f, fallback * 1.18f, 128, 9f);
        }

        public static Texture2D Noise(Color a, Color b, int size, float scale)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Repeat;
            tex.filterMode = FilterMode.Bilinear;
            var px = new Color32[size * size];
            float ox = Random.Range(0f, 50f);
            float oz = Random.Range(0f, 50f);
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float n = Mathf.PerlinNoise(ox + x / (float)size * scale, oz + y / (float)size * scale);
                    n = Mathf.Clamp01(n * 0.75f + Mathf.PerlinNoise(ox * 2f + x / (float)size * scale * 3f, oz * 2f + y / (float)size * scale * 3f) * 0.25f);
                    var c = Color.Lerp(a, b, n);
                    px[y * size + x] = c;
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }

        public static Texture2D SoftCircle(int size, float hardness)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            var px = new Color32[size * size];
            float half = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(half, half)) / half;
                    float a = 1f - Mathf.SmoothStep(hardness, 1f, d);
                    px[y * size + x] = new Color(1f, 1f, 1f, a);
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }

        public static Texture2D Ring(int size, float inner, float outer)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            var px = new Color32[size * size];
            float half = size * 0.5f;
            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float d = Vector2.Distance(new Vector2(x, y), new Vector2(half, half)) / half;
                    float a = Mathf.Clamp01(1f - Mathf.Abs(d - (inner + outer) * 0.5f) / Mathf.Max(0.01f, (outer - inner) * 0.5f));
                    a = Mathf.SmoothStep(0f, 1f, a);
                    px[y * size + x] = new Color(1f, 1f, 1f, a);
                }
            }
            tex.SetPixels32(px);
            tex.Apply();
            return tex;
        }
    }
}
