#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;

namespace TF.EditorTools
{
    public static class TFSetup
    {
        public const string ScenePath = "Assets/Scenes/Main.unity";

        [InitializeOnLoadMethod]
        static void AutoSetup()
        {
            if (Application.isBatchMode) return;
            EditorApplication.delayCall += () =>
            {
                if (SessionState.GetBool("TF_AutoSetup", false)) return;
                SessionState.SetBool("TF_AutoSetup", true);
                if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null)
                    Setup();
            };
        }

        [MenuItem("T-F/1. Setup Project (scene + IL2CPP settings)", false, 1)]
        public static void Setup()
        {
            if (EditorApplication.isPlaying)
            {
                EditorUtility.DisplayDialog("T-F", "Останови Play Mode перед настройкой проекта.", "OK");
                return;
            }
            EnsureStandardMaterial();
            try
            {
                ApplySettings();
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("[T-F] Не все Android-настройки применились (модуль Android не установлен?). " + e.Message);
            }
            if (!EnsureScene()) return;
            AssetDatabase.SaveAssets();
            Debug.Log("[T-F] Проект настроен: сцена " + ScenePath + ", IL2CPP/ARM64, без анти-чита.");
        }

        [MenuItem("T-F/0. Open Main Scene", false, 0)]
        public static void OpenScene()
        {
            if (EditorApplication.isPlaying) return;
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) == null && !EnsureScene()) return;
            EditorSceneManager.OpenScene(ScenePath);
        }

        public static void ApplySettings()
        {
            PlayerSettings.companyName = "kindmops";
            PlayerSettings.productName = "TF Drone Strike";
            PlayerSettings.bundleVersion = "1.0";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.kindmops.tfdrone");
            PlayerSettings.colorSpace = ColorSpace.Gamma;
            PlayerSettings.gcIncremental = true;
            PlayerSettings.stripEngineCode = false;
            PlayerSettings.fullScreenMode = FullScreenMode.FullScreenWindow;
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;

            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetIl2CppCompilerConfiguration(BuildTargetGroup.Android, Il2CppCompilerConfiguration.Release);
            PlayerSettings.SetManagedStrippingLevel(BuildTargetGroup.Android, ManagedStrippingLevel.Minimal);
            PlayerSettings.SetUseDefaultGraphicsAPIs(BuildTarget.Android, false);
            PlayerSettings.SetGraphicsAPIs(BuildTarget.Android, new[] { GraphicsDeviceType.OpenGLES3 });

            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
            PlayerSettings.Android.bundleVersionCode = 1;

            EditorUserBuildSettings.androidBuildSystem = AndroidBuildSystem.Gradle;
            EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
            EditorUserBuildSettings.development = false;
            EditorUserBuildSettings.allowDebugging = false;
            EditorUserBuildSettings.buildAppBundle = false;
        }

        public static void EnsureStandardMaterial()
        {
            if (!AssetDatabase.IsValidFolder("Assets/Resources"))
                AssetDatabase.CreateFolder("Assets", "Resources");
            const string path = "Assets/Resources/TFStandard.mat";
            if (AssetDatabase.LoadAssetAtPath<Material>(path) != null) return;

            var sh = Shader.Find("Standard");
            if (sh == null) sh = Shader.Find("Sprites/Default");
            if (sh == null)
            {
                Debug.LogWarning("[T-F] Не найден шейдер Standard — материалы создадутся с fallback-шейдером.");
                return;
            }
            var mat = new Material(sh);
            mat.name = "TFStandard";
            AssetDatabase.CreateAsset(mat, path);
            AssetDatabase.SaveAssets();
        }

        public static bool EnsureScene()
        {
            if (!AssetDatabase.IsValidFolder("Assets/Scenes"))
                AssetDatabase.CreateFolder("Assets", "Scenes");

            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                var scene = EditorSceneManager.OpenScene(ScenePath, OpenSceneMode.Single);
                var existing = Object.FindObjectOfType<Bootstrap>();
                if (existing == null)
                {
                    var go = new GameObject("Bootstrap");
                    go.AddComponent<Bootstrap>();
                    EditorSceneManager.MarkSceneDirty(scene);
                    EditorSceneManager.SaveScene(scene, ScenePath);
                }
            }
            else
            {
                if (!Application.isBatchMode && !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                    return false;
                var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                var go = new GameObject("Bootstrap");
                go.AddComponent<Bootstrap>();
                EditorSceneManager.SaveScene(scene, ScenePath);
            }

            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            return true;
        }
    }
}
#endif
