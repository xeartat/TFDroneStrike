#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace TF.EditorTools
{
    public static class TFBuild
    {
        [MenuItem("T-F/2. Build APK (IL2CPP ARM64)", false, 2)]
        public static void BuildAPK()
        {
            Build(false);
        }

        [MenuItem("T-F/3. Build AAB (Google Play)", false, 3)]
        public static void BuildAAB()
        {
            Build(true);
        }

        static void Build(bool appBundle)
        {
            if (EditorApplication.isPlaying)
            {
                EditorUtility.DisplayDialog("T-F", "Останови Play Mode перед сборкой.", "OK");
                return;
            }
            if (!BuildPipeline.IsBuildTargetSupported(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogError("[T-F] Android Build Support не установлен. Unity Hub -> Installs -> Add Modules -> Android Build Support (SDK/NDK/JDK).");
                return;
            }

            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android &&
                !EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android))
            {
                Debug.LogError("[T-F] Не удалось переключиться на Android. Переключи платформу в Build Settings вручную.");
                return;
            }

            TFSetup.EnsureStandardMaterial();
            TFSetup.ApplySettings();
            if (!TFSetup.EnsureScene()) return;

            Directory.CreateDirectory("Builds");
            string file = appBundle ? "Builds/TFDroneStrike.aab" : "Builds/TFDroneStrike.apk";
            EditorUserBuildSettings.buildAppBundle = appBundle;

            var options = new BuildPlayerOptions
            {
                scenes = new[] { TFSetup.ScenePath },
                locationPathName = file,
                target = BuildTarget.Android,
                options = BuildOptions.None
            };

            BuildReport report = BuildPipeline.BuildPlayer(options);
            EditorUserBuildSettings.buildAppBundle = false;

            if (report.summary.result == BuildResult.Succeeded)
            {
                Debug.Log("[T-F] СБОРКА OK: " + Path.GetFullPath(file) +
                          "  (" + (report.summary.totalSize / (1024f * 1024f)).ToString("0.0") + " МБ)");
                if (Application.isBatchMode) EditorApplication.Exit(0);
            }
            else
            {
                Debug.LogError("[T-F] СБОРКА ПРОВАЛЕНА: " + report.summary.result +
                               ", ошибок: " + report.summary.totalErrors);
                if (Application.isBatchMode) EditorApplication.Exit(1);
            }
        }
    }
}
#endif
